# Xenius Stream Lab P31 — standalone full-res RAW probe (vivo X300 Ultra)

Built on the P27 source (P26 50/200 MP capture path + F200 BlackLevel fix). Separate package
`com.xenius.streamlab`, installs next to GCam / P27.

New in P31
- **Dump all cameras + keys**: IDs 0-15 (hidden ones included): stream maps (normal + MAX_RES), binning
  factor, every characteristic incl. vendor tags (com.vivo.*, org.quic.*), request/session/result key
  lists -> `Download/XeniusLab/XLAB_camdump_*.txt`.
- **Variant** (session + every request of one camera open):
  V0 base · V1-V4 `vivo.control.EngineerRemosaicMode` = 0..3 · V5
  `org.codeaurora.qcamera3.sessionParameters.EnableXCFAOptimization` = 1 · V6 NOISE_REDUCTION + EDGE off.
  Vendor keys are tried as int32, then byte; acceptance is logged (VARIANT_APPLIED).
- **Block test** on every captured frame (1024x1024 centre crop): BAYER / QUAD 2x2 / 4x4, with
  neighbour-difference ratios and 4x4 phase means (BLOCK_TEST line). Logs echoed result keys
  (RESULT_ECHO).
- DNG names carry the variant: `XLAB_<id>_<H50|F200>_<variant>_<ts>.dng` in DCIM/XeniusFullRes.
- **Save this log** -> `Download/XeniusLab/XLAB_log_*.txt`.
