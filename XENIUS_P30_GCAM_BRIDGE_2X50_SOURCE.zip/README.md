# Xenius GCam Bridge P30 — stage A: matched 2 × 50 MP RAW with metadata

This is a real **Camera2 integration prerequisite**, NOT a native GCam HDR+ merger. The stable P24 GCam and P29 F200 capture are unchanged.

**Test:** Launch P30, open **H85 / 50 MP (ID 5)**, then **P30 GCAM BRIDGE: 2 × 50 MP RAW + metadata**. Expect `BURST_2_FINAL ... saved=2/2`, `GCAM_BRIDGE_FRAME_READY` twice and `GCAM_BRIDGE_PAIR_READY ... nativeHDRMerged=false`. Then repeat with H35 / ID 3. Do **not** use the 200 MP button for this test. Close camera / restore Vivo key40.

**Output:** Two normal 8192×6144 DNG files in DCIM/XeniusFullRes, two JSON metadata sidecars in Downloads/XeniusFullResBridge. Every frame is paired to its own CaptureResult by SENSOR_TIMESTAMP, including exposure time, ISO, WB, reported black/white and sensor noise profile. Hard-coded display **black 64/white 1023** are verified from prior P27 DNG tests but **do not imply** GCam merger has accepted them. No RGB tonemapping or GCam native calls are made. The full-res still preview is stopped before burst.

**Why needed:** P29 confirms two F200 images, but existing LMC8.3 HDR+ consumes 12MP ZSL frames. We first verify two separately calibrated 50MP inputs and an export boundary; next step is patching the LMC Camera2 capture owner and frame-injection path. GCamModuleJNI exports burst lifecycle hooks but does not reveal a standalone public `AddRawFrame` API. Actual native HDR+ integration requires tracing the obfuscated GCam image pump.

**Safeguards:** New package ID `com.xenius.gcambridge50` installs separately; the P29 two × F200 button and F200 BlackLevel TIFF fix are preserved. Each DNG is saved using its own result on a serial writer thread. Data export does not change RAW pixels.
