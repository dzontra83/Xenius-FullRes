# Xenius Latency Lab P36 — 50 MP shutter-path timing (vivo X300 Ultra)

Separate app (`com.xenius.latencylab`), built from Stream Lab P35. It opens the real 50 MP path (key40 gate,
full-res session: 12 MP RAW preview + 8192x6144 RAW + YUV, vivo ProRAW keys) and measures, per run:
- shutter -> exposure start of the first 50 MP frame (when SENSOR_INFO_TIMESTAMP_SOURCE is REALTIME)
- shutter -> first / last 50 MP frame delivered to the app
- 50 MP frame period (sensor timestamps) and burst exposure span
- longest preview gap (sensor mode switch blackout)
Runs: 3 x DIRECT (burst sent at "shutter") and 3 x TRIGGER (12 MP still first, burst after its result, as
Xenius GCam does). Options: burst 1 / 5 / 10, `vivo.control.seamless.remosaic.enable` 0 / 1. No images are saved.
