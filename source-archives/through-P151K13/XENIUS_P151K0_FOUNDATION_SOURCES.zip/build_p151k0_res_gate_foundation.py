#!/usr/bin/env python3
"""P151K0 RES/Camera2 lifecycle *instrumentation foundation*.
Not yet a working RES 12MP<->50MP mode switch. Precisely patched baseline P151J TEST2.
Uses preexisting Dalvik strings & method IDs (no references/strings/manifest changes).
Preserves key40 helper unchanged: its apparent add v4+1 uses vendor getInfo(40), NOT owner counter.
"""
from pathlib import Path
import sys, struct, hashlib, zlib, zipfile
sys.path.insert(0, '/mnt/data')
from dexlite import Dex
from verify_p151h_fix4_dalvik import insn_lengths
R = Path('/mnt/data')
src = R/'XENIUS_P151J_TEST2_REENTRY_GATE_RECHECK_UNSIGNED.apk'
out = R/'XENIUS_P151K0_RES_GATE_FOUNDATION_UNSIGNED.apk'
with zipfile.ZipFile(src) as zi:
    assert zi.testzip() is None
    s1=zi.read('classes.dex'); s2=zi.read('classes2.dex')
    names=zi.namelist()
(R/'_p151k0_orig.dex').write_bytes(s1)
d = Dex(str(R/'_p151k0_orig.dex'))
assert d.strings.index('RESOLUTION_SWITCH')<65536
logmethod = next(i for i,(c,n,p) in enumerate(d.methods) if c=='Landroid/util/Log;' and n=='i' and p==310)
print('Log.i method ID',logmethod)
# onResume (already has gate activation at start) logs event, then original resume+gate execution.
# onStop logs entry (not a camera-close event), existing stop unchanged.
# onClosed logs callback, then original nonnull helper release and ImageReader cleanup.
patches={
  15529:('onResume', [0x001a,d.strings.index('RESOLUTION_SWITCH'),0x011a,d.strings.index('onResume'),0x2071,logmethod,0x0010]),
  15531:('onStop',[0x001a,d.strings.index('RESOLUTION_SWITCH'),0x011a,d.strings.index('onStop'),0x2071,logmethod,0x0010]),
  43577:('onClosed',[0x001a,d.strings.index('onClosed'),0x2071,logmethod,0x0000])
}
# Assertions that prefixes use locals only, no parameter clobbering.
assert d.u16(d.code[15529][0])==4 and d.u16(d.code[15529][0]+2)==1
assert d.u16(d.code[15531][0])==3 and d.u16(d.code[15531][0]+2)==1
assert d.u16(d.code[43577][0])==3 and d.u16(d.code[43577][0]+2)==2

def uleb(b,pos):
 v=0;sh=0
 for _ in range(5):
  z=b[pos];pos+=1;v|=(z&127)<<sh;sh+=7
  if z<128:return v,pos
 raise ValueError('ULEB')
def enculeb(v):
 o=[]
 while 1:
  z=v&127;v>>=7;o.append(z|128 if v else z)
  if not v:return bytes(o)
mapoff=d.u32(0x34)
entries=[struct.unpack_from('<HHII',s1,mapoff+4+i*12) for i in range(d.u32(mapoff))]
mp={t:(count,off) for t,_,count,off in entries}
insert_at=mp[0x2000][1]
assert insert_at%4==0 and insert_at>0
newitems=bytearray();newpositions={};newwords={}
for mid,(label,prefix) in patches.items():
    co,ac,klass=d.code[mid]
    assert d.u16(co+6)==0,(mid,'unexpected try blocks')
    siz=d.u32(co+12)
    orig=list(struct.unpack_from('<%dH'%siz,s1,co+16))
    sites,br=insn_lengths(orig)
    merged=prefix+orig
    ns,nb=insn_lengths(merged)
    assert len(nb)==len(br)
    assert all((oldpc+len(prefix) in ns and ns[oldpc+len(prefix)]==item) for oldpc,item in sites.items())
    assert all(dst in sites for _,dst in br)
    assert all(dst in ns for _,dst in nb)
    assert d.u32(co+8)==0 or True
    if len(newitems)%4:newitems+=b'\0'*(-len(newitems)%4)
    newpositions[mid]=insert_at+len(newitems)
    b=bytearray(s1[co:co+16]); struct.pack_into('<I',b,12,len(merged))
    if mid==15531:  # Log.i(tag,msg) requires 2 outgoing argument slots.
        assert struct.unpack_from('<H',b,4)[0]==1
        struct.pack_into('<H',b,4,2)
    b+=struct.pack('<%dH'%len(merged),*merged)
    b+=b'\0'*(-len(b)%4)
    newitems+=b
    newwords[mid]=merged
    print(label, 'orig CU',siz,'new CU',len(merged),'at',hex(newpositions[mid]),'added',len(b))
assert len(newitems)%4==0
delta=len(newitems)
b=bytearray(s1[:insert_at]+newitems+s1[insert_at:])
for i in range(d.class_defs_size):
 at=d.class_defs_off+32*i+24
 coff=d.u32(at)
 if coff:
  assert coff>=insert_at
  struct.pack_into('<I',b,at,coff+delta)
# Replace code_off ULEB in class_data, no rewriting of variable-length structures.
found=[]
for i in range(d.class_defs_size):
 cd=d.u32(d.class_defs_off+32*i+24)
 if not cd:continue
 p=cd
 st,p=uleb(s1,p);ins,p=uleb(s1,p);direct,p=uleb(s1,p);virt,p=uleb(s1,p)
 for n in (st,ins):
  for j in range(n):
   _,p=uleb(s1,p);_,p=uleb(s1,p)
 for n in (direct,virt):
  last=0
  for j in range(n):
   diff,p=uleb(s1,p);last+=diff
   _,p=uleb(s1,p)
   start=p;co,p=uleb(s1,p)
   if last in newpositions:
    assert co==d.code[last][0]
    rep=enculeb(newpositions[last]);assert len(rep)==p-start,(last,rep,p-start)
    b[start+delta:p+delta]=rep
    found.append(last)
assert sorted(found)==sorted(newpositions)
# update headers/map
struct.pack_into('<I',b,0x20,len(b))
struct.pack_into('<I',b,0x34,mapoff+delta)
struct.pack_into('<I',b,0x68,d.u32(0x68)+delta)
for idx,(typ,unused,num,off) in enumerate(entries):
 if typ==0x2001:num+=len(patches)
 if off>=insert_at:off+=delta
 struct.pack_into('<HHII',b,mapoff+delta+4+idx*12,typ,unused,num,off)
b[12:32]=hashlib.sha1(b[32:]).digest()
struct.pack_into('<I',b,8,zlib.adler32(b[12:])&0xffffffff)
(R/'P151K0_FOUNDATION_classes.dex').write_bytes(b)
x=Dex(str(R/'P151K0_FOUNDATION_classes.dex'))
assert x.methods==d.methods and len(x.code)==len(d.code)
for mid,(oldco,ac,klass) in d.code.items():
 co,ac2,klass2=x.code[mid]
 assert (ac,klass)==(ac2,klass2)
 assert co==(newpositions[mid] if mid in patches else oldco),(mid,co,oldco)
 if mid not in patches and co:
  sz=d.u32(oldco+12)
  assert s1[oldco:oldco+16+2*sz]==b[co:co+16+2*sz],mid
for mid,newpc in newpositions.items():
 assert x.u32(newpc+12)==len(newwords[mid])
 assert x.u16(newpc+4)>= (2 if mid==15531 else 1)
 sites,br=insn_lengths(newwords[mid]);assert all(t in sites for _,t in br)
# Preserve the P151J TEST2 key40 helper byte-identically. The apparent
# CU462 "add-int/lit8 v4,v4,1" operates on the vendor getInfo(40) readback (v4),
# not on the in-process Aemodef marker. On the acquire branch, v4=0 at this
# point; replacing it with constant1 would be redundant and not fix the leak.
z=bytearray(s2)
(R/'P151K0_FOUNDATION_classes2.dex').write_bytes(z)
qpath=R/'P151K0_FOUNDATION_classes2.dex'
q=Dex(str(qpath))
assert q.methods and q.methods[646][:2]==('LMC/c2a;','getC2apiPref')
assert q.data==s2
# Reassemble archive retaining native libraries and Android resources unchanged.
with zipfile.ZipFile(src) as zin,zipfile.ZipFile(out,'w',allowZip64=True) as zout:
 for ent in zin.infolist():
  if ent.filename.startswith('META-INF/') and ent.filename.upper().endswith(('.SF','.RSA','.DSA','.EC','.MF')):continue
  inf=zipfile.ZipInfo(ent.filename,ent.date_time)
  inf.compress_type=ent.compress_type;inf.external_attr=ent.external_attr;inf.internal_attr=ent.internal_attr
  inf.create_system=ent.create_system;inf.flag_bits=ent.flag_bits &~8;inf.comment=ent.comment;inf.extra=b''
  if ent.filename=='resources.arsc' and ent.compress_type==zipfile.ZIP_STORED:
   pad=(-(zout.fp.tell()+30+len(ent.filename.encode())+4))%4
   inf.extra=struct.pack('<HH',0xD935,pad)+b'\0'*pad
  raw=bytes(b) if ent.filename=='classes.dex' else bytes(z) if ent.filename=='classes2.dex' else zin.read(ent.filename)
  zout.writestr(inf,raw,compress_type=inf.compress_type,compresslevel=6)
with zipfile.ZipFile(src) as zin,zipfile.ZipFile(out) as zout:
 assert zout.testzip() is None
 assert zout.read('classes.dex')==b and zout.read('classes2.dex')==z
 for name in names:
  if name in ('classes.dex','classes2.dex') or (name.startswith('META-INF/') and name.upper().endswith(('.SF','.RSA','.DSA','.EC','.MF'))):continue
  assert zin.getinfo(name).CRC==zout.getinfo(name).CRC,name
 info=zout.getinfo('resources.arsc')
 assert (info.header_offset+30+len(info.filename.encode())+len(info.extra))%4==0
 print('FINAL APK',str(out),'size',out.stat().st_size,'sha256',hashlib.sha256(out.read_bytes()).hexdigest())
 print('DEX CRC',zout.getinfo('classes.dex').CRC,'DEX2 CRC',zout.getinfo('classes2.dex').CRC)
