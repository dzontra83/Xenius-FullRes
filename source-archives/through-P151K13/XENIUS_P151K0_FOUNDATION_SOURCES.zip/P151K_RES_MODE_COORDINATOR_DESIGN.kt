/*
 * XENIUS P151K — RES 12MP / 50MP ownership contract (DESIGN SOURCE ONLY).
 * NOT injected into P151K0 APK. The Xenius obfuscated RES event and both
 * Camera2 device callbacks must first be mapped and wired correctly.
 * No Android permissions or vendor keys are silently modified in this file.
 * All entrypoints should be dispatched on one dedicated camera lifecycle thread.
 */
package xenius.resmode.design

enum class ResMode { MP12, MP50 }
enum class CameraPhase { CLOSED, OPENING, ACTIVE, CLOSING, ERROR }

data class GateLease(val previous: Int, val captureEpoch: Long)

interface Key40Port {
    fun read(): Int           // hidden VivoCameraManager.getInfo(40); returns actual value
    fun set(value: Int)       // hidden VivoCameraManager.setValue(40, value)
    fun saveRecoveryJournal(previous: Int, epoch: Long) // commit BEFORE enabling
    fun clearRecoveryJournal()
}
interface CameraPort {
    fun open(mode: ResMode, epoch: Long)
    fun close(epoch: Long) // asynchronous: does NOT imply the device is closed
    fun shutterEnabled(enabled: Boolean)
}
interface DiagnosticPort {
    fun log(name: String, epoch: Long, detail: String)
}

/**
 * Deterministic transition coordinator. Requires real CameraDevice.StateCallback.onClosed
 * for EVERY camera-open path, including Xenius's alternate Larb/Laqx route.
 * Callbacks must be executed on the same serialized camera lifecycle dispatcher.
 */
class ResModeCoordinator(
    private val gate: Key40Port,
    private val camera: CameraPort,
    private val log: DiagnosticPort
) {
    private var phase = CameraPhase.CLOSED
    private var foreground = false
    private var requestedMode = ResMode.MP12
    private var openedMode: ResMode? = null
    private var epoch = 0L
    private var cameraEpoch = 0L
    private var outstanding = 0
    private var lease: GateLease? = null

    fun onViewfinderShown() {
        foreground = true
        drive()
    }
    fun onResSelected(mode: ResMode) {
        requestedMode = mode
        log.log("RES_SELECTED", epoch, mode.name)
        drive()
    }
    fun onViewfinderHidden() {
        foreground = false
        drive()
    }
    fun onCaptureAccepted() {
        check(phase == CameraPhase.ACTIVE && foreground)
        outstanding++
    }
    fun onCaptureFinished() {
        check(outstanding > 0)
        outstanding--
        drive()
    }
    fun onDeviceOpened(callbackEpoch: Long) {
        if (callbackEpoch != cameraEpoch || phase != CameraPhase.OPENING) return
        phase = CameraPhase.ACTIVE
        log.log("DEVICE_OPENED", callbackEpoch, openedMode!!.name)
        drive()
    }
    fun onDeviceClosed(callbackEpoch: Long) {
        if (callbackEpoch != cameraEpoch || phase != CameraPhase.CLOSING) {
            log.log("IGNORED_STALE_CLOSE", callbackEpoch, "active=$cameraEpoch")
            return
        }
        log.log("DEVICE_CLOSED", callbackEpoch, openedMode?.name ?: "none")
        // Never release while a capture is still using Camera2/HAL buffers.
        check(outstanding == 0)
        if (openedMode == ResMode.MP50) releaseGate(callbackEpoch)
        openedMode = null
        phase = CameraPhase.CLOSED
        drive()
    }
    fun onCameraError(callbackEpoch: Long, message: String) {
        if (callbackEpoch != cameraEpoch) return
        log.log("CAMERA_ERROR", callbackEpoch, message)
        if (phase == CameraPhase.ACTIVE || phase == CameraPhase.OPENING) {
            phase = CameraPhase.CLOSING
            camera.shutterEnabled(false)
            camera.close(callbackEpoch)
        }
        // The real onClosed event (or verified idle recovery) must follow.
    }
    private fun drive() {
        when (phase) {
            CameraPhase.CLOSED -> {
                if (!foreground) return
                openRequested()
            }
            CameraPhase.OPENING -> camera.shutterEnabled(false)
            CameraPhase.ACTIVE -> {
                if (!foreground || openedMode != requestedMode) {
                    if (outstanding != 0) return
                    phase = CameraPhase.CLOSING
                    camera.shutterEnabled(false)
                    log.log("DEVICE_CLOSE_REQUEST", cameraEpoch, "res=${openedMode}")
                    camera.close(cameraEpoch)
                } else camera.shutterEnabled(true)
            }
            CameraPhase.CLOSING -> camera.shutterEnabled(false)
            CameraPhase.ERROR -> camera.shutterEnabled(false)
        }
    }
    private fun openRequested() {
        camera.shutterEnabled(false)
        epoch++
        cameraEpoch = epoch
        if (requestedMode == ResMode.MP50) {
            try { acquireGate(cameraEpoch) }
            catch (e: Exception) {
                phase = CameraPhase.ERROR
                log.log("GATE_ACQUIRE_FAILED", cameraEpoch, e.toString())
                return
            }
        }
        openedMode = requestedMode
        phase = CameraPhase.OPENING
        log.log("DEVICE_OPEN_REQUEST", cameraEpoch, openedMode!!.name)
        camera.open(openedMode!!, cameraEpoch)
    }
    private fun acquireGate(forEpoch: Long) {
        check(lease == null)
        val previous = gate.read()
        gate.saveRecoveryJournal(previous, forEpoch)
        lease = GateLease(previous, forEpoch)
        gate.set(1)
        val verified = gate.read()
        log.log("GATE_ACQUIRED", forEpoch, "previous=$previous readback=$verified")
        check(verified == 1) { "key40 activation failed: actual=$verified" }
    }
    private fun releaseGate(forEpoch: Long) {
        val owned = lease ?: return
        gate.set(owned.previous)
        val verified = gate.read()
        log.log("GATE_RELEASED", forEpoch, "restore=${owned.previous} readback=$verified")
        if (verified == owned.previous) {
            gate.clearRecoveryJournal()
            lease = null
        } else {
            phase = CameraPhase.ERROR
            error("key40 restore failed: expected=${owned.previous} actual=$verified")
        }
    }
}
