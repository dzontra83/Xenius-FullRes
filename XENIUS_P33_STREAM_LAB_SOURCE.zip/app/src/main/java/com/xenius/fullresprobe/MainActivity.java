package com.xenius.fullresprobe;

import android.Manifest;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.ImageFormat;
import android.hardware.HardwareBuffer;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.CaptureResult;
import android.hardware.camera2.DngCreator;
import android.hardware.camera2.TotalCaptureResult;
import android.hardware.camera2.params.OutputConfiguration;
import android.hardware.camera2.params.SessionConfiguration;
import android.media.Image;
import android.media.ImageReader;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.system.Os;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.util.Log;
import android.util.Range;
import android.view.View;
import android.view.OrientationEventListener;
import android.view.Surface;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.OutputStream;
import java.io.FileDescriptor;
import java.nio.ByteOrder;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Independent Camera2 experiment informed by publicly documented Vivo protocol.
 * Does not modify an existing GCam package and does not reuse RawR source code.
 * Capture is experimental: HAL may reject stream sizes, keys or DNG metadata.
 */
public final class MainActivity extends Activity {
    private static final String TAG = "XENIUS_LAB_P33";
    private static final int PERMISSION_REQUEST = 25;
    private static final int RAW_W = 4080, RAW_H_H85 = 3072, RAW_H_H35 = 3064;
    private static final int H_FULL_W = 8192, H_FULL_H = 6144;
    private static final int F_FULL_W = 16320, F_FULL_H_85 = 12288, F_FULL_H_35 = 12256;
    private static final int YUV_W = 640, YUV_H = 480;
    private HandlerThread workerThread;
    private Handler worker;
    private Executor cameraExecutor;
    private TextView report;
    private CameraManager cameraManager;
    private CameraDevice device;
    private CameraCaptureSession session;
    private ImageReader rawReader, fullReader, yuvReader;
    private CameraCharacteristics characteristics;
    private String activeCameraId;
    private int activePreviewHeight = RAW_H_H85;
    private int activeFullWidth = H_FULL_W, activeFullHeight = H_FULL_H;
    private boolean active200 = false;
    private boolean captureInFlight = false;
    private boolean decisionPending = false;
    private int captureGeneration = 0;
    private long previewExposureNs = 33333333L;
    private int capturedImages = 0;
    private volatile int deviceOrientationDegrees = -1;
    private OrientationEventListener orientationListener;
    private int captureExifOrientation = ExifInterface.ORIENTATION_NORMAL;
    private boolean openPending = false;
    private boolean previewSwitched = false;
    private final AtomicReference<TotalCaptureResult> lastStillResult = new AtomicReference<>();
    private final VivoGate gate = new VivoGate();

    // ---- P31 Stream Lab: test variants (applied to session + every request of one open) ----
    private static final String ERM = "vivo.control.EngineerRemosaicMode";
    private static final String XCFA = "org.codeaurora.qcamera3.sessionParameters.EnableXCFAOptimization";
    private static final String SEAMLESS = "vivo.control.seamless.remosaic.enable";
    private static final String FSM = "vivo.control.forceSensorMode";
    private static final String[] VARIANTS = {
            "V0-BASE", "V1-SEAMLESS1", "V2-ERM4", "V3-ERM5", "V4-ERM6", "V5-ERM8", "V6-NROFF", "V7-FSM"};
    private static final int[] ERM_VALUES = {0, 0, 4, 5, 6, 8};
    private int fsmValue = 0;          // forceSensorMode used by V7
    private int activeFsm = 0;
    private Button fsmButton;
    private static boolean calibrationSaved = false;
    private int variant = 0;          // selected with the Variant button (camera closed)
    private int activeVariant = 0;    // locked when the camera opens
    private boolean variantLogged = false;
    private Button variantButton;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        workerThread = new HandlerThread("xenius-lab-camera");
        workerThread.start();
        worker = new Handler(workerThread.getLooper());
        cameraExecutor = r -> worker.post(r);
        cameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(18, 16, 18, 16);
        addButton(root, "Dump all cameras + keys to Download/XeniusLab", () -> worker.post(this::dumpCameras));
        variantButton = addButton(root, "Variant: " + VARIANTS[variant] + "  (tap to change)", this::cycleVariant);
        fsmButton = addButton(root, "V7 forceSensorMode value: " + fsmValue + "  (tap +1)", this::cycleFsm);
        addButton(root, "Auto sweep forceSensorMode from V7 value to " + SWEEP_MAX + " (ID 5, 12 MP RAW)", () -> worker.post(this::startSweep));
        addButton(root, "1. Check Vivo key40", () -> worker.post(this::checkGate));
        addButton(root, "Open H85 / 50 MP (ID 5)", () -> worker.post(() -> openMode("5", false)));
        addButton(root, "Open H35 / 50 MP (ID 3)", () -> worker.post(() -> openMode("3", false)));
        addButton(root, "Open F85 / 200 MP (ID 5)", () -> worker.post(() -> openMode("5", true)));
        addButton(root, "Open F35 / 200 MP (ID 3)", () -> worker.post(() -> openMode("3", true)));
        addButton(root, "Capture current lens / 50 or 200 MP", () -> worker.post(this::captureSelected));
        addButton(root, "Close camera / restore Vivo key40", () -> worker.post(this::closeCamera));
        addButton(root, "Save this log to Download/XeniusLab", () -> worker.post(this::saveLog));
        report = new TextView(this);
        report.setTextSize(12);
        report.setTextIsSelectable(true);
        report.setText("P33 Stream Lab: pick a Variant, open a lens, Capture. Each DNG gets a block test "
                + "(BAYER / QUAD 2x2 / 4x4). Close the camera before changing Variant.\n");
        ScrollView scroll = new ScrollView(this);
        scroll.addView(report);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
        orientationListener = new OrientationEventListener(this) {
            @Override public void onOrientationChanged(int orientation) {
                if (orientation != OrientationEventListener.ORIENTATION_UNKNOWN) {
                    deviceOrientationDegrees = ((orientation + 45) / 90 * 90) % 360;
                }
            }
        };
        if (orientationListener.canDetectOrientation()) orientationListener.enable();
        worker.post(gate::recoverIfLeftActive);
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, PERMISSION_REQUEST);
        }
    }

    private Button addButton(LinearLayout parent, String title, Runnable action) {
        Button b = new Button(this);
        b.setText(title);
        b.setAllCaps(false);
        b.setOnClickListener(v -> action.run());
        parent.addView(b, new LinearLayout.LayoutParams(-1, -2));
        return b;
    }

    private void cycleVariant() {
        if (device != null || session != null || openPending) {
            info("VARIANT_LOCKED", "Close the camera first, then change Variant");
            return;
        }
        variant = (variant + 1) % VARIANTS.length;
        variantButton.setText("Variant: " + VARIANTS[variant] + "  (tap to change)");
        info("VARIANT_SELECTED", VARIANTS[variant]);
    }

    private void cycleFsm() {
        if (device != null || session != null || openPending) {
            info("VARIANT_LOCKED", "Close the camera first, then change the V7 value");
            return;
        }
        fsmValue = (fsmValue + 1) % (SWEEP_MAX + 1);
        fsmButton.setText("V7 forceSensorMode value: " + fsmValue + "  (tap +1)");
        info("FSM_SELECTED", "V7 will use forceSensorMode=" + fsmValue);
    }

    private String variantLabel() {
        return activeVariant == 7 ? "V7-FSM" + activeFsm : VARIANTS[activeVariant];
    }

    /** Vendor key with unknown type: try int32, then byte. Logs the outcome once per open. */
    private void tryKey(CaptureRequest.Builder b, String name, int v, List<String> log) {
        try { intKey(b, name, v); log.add(name + "=" + v + "(i32 ok)"); return; }
        catch (Exception e) { log.add(name + " i32 refused: " + e.getClass().getSimpleName()); }
        try { byteKey(b, name, (byte) v); log.add(name + "=" + v + "(byte ok)"); }
        catch (Exception e) { log.add(name + " byte refused: " + e.getClass().getSimpleName()); }
    }

    private void applyVariant(CaptureRequest.Builder b) {
        List<String> log = new ArrayList<>();
        switch (activeVariant) {
            case 1: tryKey(b, SEAMLESS, 1, log); break;
            case 2: case 3: case 4: case 5: tryKey(b, ERM, ERM_VALUES[activeVariant], log); break;
            case 7: tryKey(b, FSM, activeFsm, log); break;
            case 6:
                b.set(CaptureRequest.NOISE_REDUCTION_MODE, CaptureRequest.NOISE_REDUCTION_MODE_OFF);
                b.set(CaptureRequest.EDGE_MODE, CaptureRequest.EDGE_MODE_OFF);
                log.add("NR=OFF EDGE=OFF");
                break;
            default: log.add("no extra keys");
        }
        if (!variantLogged) { variantLogged = true; info("VARIANT_APPLIED", variantLabel() + " " + log); }
    }

    private void info(String event, String detail) {
        String line = event + " " + detail;
        Log.i(TAG, line);
        runOnUiThread(() -> report.append(line + "\n"));
    }
    private void fail(String stage, Exception error) {
        Log.e(TAG, stage, error);
        info("ERROR", stage + " " + error.toString());
    }

    private void checkGate() {
        try {
            int value = gate.peek();
            info("VIVO_GATE_PROBE", "key40_before=" + value + " device=" + Build.MODEL);
        } catch (Exception e) { fail("VIVO_GATE_UNAVAILABLE", e); }
    }

    private void openMode(String id, boolean full200) {
        if (openPending || device != null || session != null) {
            info("OPEN_REFUSED", "Close the current camera first");
            return;
        }
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            info("OPEN_REFUSED", "CAMERA permission not granted");
            return;
        }
        try {
            if (!gate.acquire()) {
                info("OPEN_REFUSED", "Vivo gate unavailable / key40 not confirmed");
                return;
            }
            openPending = true;
            activeVariant = variant;
            activeFsm = fsmValue;
            variantLogged = false;
            info("VARIANT_LOCKED_FOR_OPEN", variantLabel());
            activeCameraId = id;
            active200 = full200;
            activeFullWidth = full200 ? F_FULL_W : H_FULL_W;
            activeFullHeight = full200 ? (id.equals("3") ? F_FULL_H_35 : F_FULL_H_85) : H_FULL_H;
            captureInFlight = false;
            decisionPending = false;
            previewSwitched = false;
            activePreviewHeight = id.equals("3") ? RAW_H_H35 : RAW_H_H85;
            characteristics = cameraManager.getCameraCharacteristics(id);
            info("VIVO_GATE_STATE", "stage=before_open " + gate.state());
            info("CAMERA_IDS", Arrays.toString(cameraManager.getCameraIdList()));
            info("CONFIG_TARGET", String.format(Locale.US,
                    "mode=%s camera=%s preview=%dx%d full=%dx%d RAW_SENSOR black=64 white=1023 (profile values)",
                    full200 ? "F200" : "H50", id, RAW_W, activePreviewHeight,
                    activeFullWidth, activeFullHeight));
            // Buffer usage mirrors the GPU data buffer path used by the Vivo HAL.
            long usage = HardwareBuffer.USAGE_GPU_DATA_BUFFER;
            rawReader = ImageReader.newInstance(RAW_W, activePreviewHeight, ImageFormat.RAW_SENSOR, 3, usage);
            fullReader = ImageReader.newInstance(activeFullWidth, activeFullHeight, ImageFormat.RAW_SENSOR, 2, usage);
            yuvReader = ImageReader.newInstance(YUV_W, YUV_H, ImageFormat.YUV_420_888, 3);
            rawReader.setOnImageAvailableListener(r -> onRawPreview(r), worker);
            fullReader.setOnImageAvailableListener(r -> onFullRaw(r), worker);
            yuvReader.setOnImageAvailableListener(r -> {
                Image image = r.acquireLatestImage();
                if (image != null) image.close();
            }, worker);
            cameraManager.openCamera(id, new CameraDevice.StateCallback() {
                @Override public void onOpened(CameraDevice c) {
                    openPending = false;
                    device = c;
                    info("CAMERA_OPENED", "id=" + id + " key40=" + gate.peekSafe());
                    configureSession(c);
                }
                @Override public void onDisconnected(CameraDevice c) {
                    openPending = false;
                    info("CAMERA_DISCONNECTED", "id=" + id);
                    c.close();
                }
                @Override public void onError(CameraDevice c, int error) {
                    openPending = false;
                    info("CAMERA_ERROR", "id=" + id + " code=" + error);
                    c.close();
                }
                @Override public void onClosed(CameraDevice c) {
                    openPending = false;
                    info("CAMERA_CLOSED", "id=" + id);
                    if (device == c) device = null;
                    cleanupReaders();
                    gate.restore();
                }
            }, worker);
        } catch (Exception e) {
            openPending = false;
            fail("CAMERA_OPEN_FAILED", e);
            closeCamera();
        }
    }

    private CaptureRequest.Builder newBuilder(int template) throws CameraAccessException {
        CaptureRequest.Builder b = device.createCaptureRequest(template);
        // Important: set both session and request scope independently.
        if (active200) {
            intKey(b, "vivo.control.ultra_highresolution", 1);
        } else {
            intKey(b, "vivo.control.ai_highresolution", 1);
            intKey(b, "vivo.control.ultra_highresolution", 0);
        }
        intKey(b, "vivo.control.is_ProRaw_on", 2);
        intKey(b, "vivo.control.echo.mode", 2);
        intKey(b, "vivo.control.scenery.subfunction", 5);
        intKey(b, "vivo.control.session.uiSwitch_state", 2);
        applyVariant(b);
        return b;
    }
    private void addRequestKeys(CaptureRequest.Builder b) {
        intKey(b, "vivo.control.is_pro_mode", 1);
        byteKey(b, "vivo.control.camera_scenery_pro", (byte)1);
    }
    private void addStillKeys(CaptureRequest.Builder b) {
        intKey(b, "com.vivo.current_ui_module", 74);
        intKey(b, "vivo.control.onlyDng", 1);
        intKey(b, "vivo.control.isCapture", 0);
        intKey(b, "vivo.control.sensorMode", 0);
        intKey(b, "vivo.control.isUpscale", active200 ? 1 : 0);
        byteKey(b, "vivo.control.isPAPNeeded", (byte)1);
        long marker = SystemClock.elapsedRealtimeNanos();
        longKey(b, "vivo.control.requestId", marker);
        longKey(b, "vivo.control.frameFlag", marker);
        longKey(b, "vivo.control.globalCaptureId", marker + 5);
    }
    private void intKey(CaptureRequest.Builder b, String name, int v) {
        b.set(new CaptureRequest.Key<>(name, Integer.class), v);
    }
    private void byteKey(CaptureRequest.Builder b, String name, byte v) {
        b.set(new CaptureRequest.Key<>(name, Byte.class), v);
    }
    private void longKey(CaptureRequest.Builder b, String name, long v) {
        b.set(new CaptureRequest.Key<>(name, Long.class), v);
    }

    private void configureSession(CameraDevice c) {
        try {
            CaptureRequest.Builder sessionKeys = newBuilder(CameraDevice.TEMPLATE_PREVIEW);
            ArrayList<OutputConfiguration> outputs = new ArrayList<>();
            outputs.add(new OutputConfiguration(rawReader.getSurface()));
            outputs.add(new OutputConfiguration(fullReader.getSurface()));
            outputs.add(new OutputConfiguration(yuvReader.getSurface()));
            SessionConfiguration config = new SessionConfiguration(
                    SessionConfiguration.SESSION_REGULAR, outputs, cameraExecutor,
                    new CameraCaptureSession.StateCallback() {
                        @Override public void onConfigured(CameraCaptureSession s) {
                            session = s;
                            info("FULLRES_SESSION_CONFIGURED", "camera=" + activeCameraId +
                                    " gate=" + gate.peekSafe() + " 3_outputs=RAW+FULLRAW+YUV");
                            info("VIVO_GATE_STATE", "stage=configured " + gate.state());
                            startPreview(true);
                        }
                        @Override public void onConfigureFailed(CameraCaptureSession s) {
                            info("FULLRES_SESSION_FAILED", "camera=" + activeCameraId);
                            info("VIVO_GATE_STATE", "stage=config_failed " + gate.state());
                            closeCamera();
                        }
                    });
            config.setSessionParameters(sessionKeys.build());
            info("FULLRES_SESSION_REQUEST", "3 outputs; gate=" + gate.peekSafe());
            c.createCaptureSession(config);
        } catch (Exception e) {
            fail("SESSION_CONFIG_EXCEPTION", e);
            closeCamera();
        }
    }

    private void startPreview(boolean includeYuv) {
        if (device == null || session == null) return;
        try {
            CaptureRequest.Builder b = newBuilder(CameraDevice.TEMPLATE_PREVIEW);
            addRequestKeys(b);
            b.addTarget(rawReader.getSurface());
            if (includeYuv) b.addTarget(yuvReader.getSurface());
            session.setRepeatingRequest(b.build(), new CameraCaptureSession.CaptureCallback() {
                @Override public void onCaptureCompleted(CameraCaptureSession s,
                        CaptureRequest request, TotalCaptureResult result) {
                    Long exposure = result.get(CaptureResult.SENSOR_EXPOSURE_TIME);
                    if (exposure != null && exposure > 0) previewExposureNs = exposure;
                }
            }, worker);
            info("RAW_PREVIEW_STARTED", "with_yuv=" + includeYuv);
        } catch (Exception e) { fail("RAW_PREVIEW_FAILED", e); }
    }

    private void onRawPreview(ImageReader reader) {
        Image image = null;
        try {
            image = reader.acquireLatestImage();
            if (image == null) return;
            if (!previewSwitched && !captureInFlight) {
                previewSwitched = true;
                info("RAW_PREVIEW_FRAME", image.getWidth() + "x" + image.getHeight());
                startPreview(false); // Keep companion configured, but stop targeting it.
            }
        } catch (Exception e) { fail("RAW_PREVIEW_IMAGE", e); }
        finally { if (image != null) image.close(); }
    }

    private int computeExifOrientation() {
        // DngCreator's unspecified orientation was 9 (TIFF/EP unknown) on V2547A.
        // Set a valid EXIF 1/3/6/8 explicitly, using sensor and device orientation.
        Integer sensorVal = characteristics == null ? null :
                characteristics.get(CameraCharacteristics.SENSOR_ORIENTATION);
        Integer facing = characteristics == null ? null :
                characteristics.get(CameraCharacteristics.LENS_FACING);
        int sensor = sensorVal == null ? 90 : sensorVal;
        int deviceDeg = deviceOrientationDegrees;
        if (deviceDeg < 0) {
            int rotation = getWindowManager().getDefaultDisplay().getRotation();
            switch (rotation) {
                case Surface.ROTATION_90: deviceDeg = 90; break;
                case Surface.ROTATION_180: deviceDeg = 180; break;
                case Surface.ROTATION_270: deviceDeg = 270; break;
                default: deviceDeg = 0;
            }
        }
        int degrees = facing != null && facing == CameraCharacteristics.LENS_FACING_FRONT
                ? (sensor + deviceDeg) % 360
                : (sensor - deviceDeg + 360) % 360;
        int exif;
        switch (degrees) {
            case 90: exif = ExifInterface.ORIENTATION_ROTATE_90; break;
            case 180: exif = ExifInterface.ORIENTATION_ROTATE_180; break;
            case 270: exif = ExifInterface.ORIENTATION_ROTATE_270; break;
            default: exif = ExifInterface.ORIENTATION_NORMAL;
        }
        info("DNG_ORIENTATION", "camera=" + activeCameraId + " device=" + deviceDeg
                + " sensor=" + sensor + " rotation=" + degrees + " exif=" + exif);
        return exif;
    }

    private void captureSelected() {
        if (device == null || session == null) {
            info("CAPTURE_REFUSED", "Camera/session not configured");
            return;
        }
        if (captureInFlight) {
            info("CAPTURE_REFUSED", "Capture in progress; wait for DNG_WRITTEN or ERROR");
            return;
        }
        captureInFlight = true;
        final int generation = ++captureGeneration;
        lastStillResult.set(null);
        captureExifOrientation = computeExifOrientation();
        info("CAPTURE_START", "mode=" + (active200 ? "F200" : "H50") + " camera=" + activeCameraId
                + " expected=" + activeFullWidth + "x" + activeFullHeight);
        worker.postDelayed(() -> {
            if (captureInFlight && generation == captureGeneration) {
                info("CAPTURE_TIMEOUT", "No completed DNG after 90 s; reset capture state");
                captureInFlight = false;
                decisionPending = false;
                if (device != null && session != null) startPreview(false);
            }
        }, 90000);
        if (active200) prepare200(generation);
        else submitStill(generation);
    }

    private void prepare200(int generation) {
        try {
            final CameraCaptureSession activeSession = session;
            decisionPending = true;
            CaptureRequest.Builder d = newBuilder(CameraDevice.TEMPLATE_PREVIEW);
            addRequestKeys(d);
            intKey(d, "com.vivo.current_ui_module", 74);
            d.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF);
            Range<Integer> iso = characteristics.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE);
            int minIso = iso == null ? 100 : iso.getLower();
            d.set(CaptureRequest.SENSOR_SENSITIVITY, minIso);
            Range<Long> exp = characteristics.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE);
            long targetExp = previewExposureNs > 0 ? previewExposureNs : 33333333L;
            if (exp != null) targetExp = Math.max(exp.getLower(), Math.min(exp.getUpper(), targetExp));
            d.set(CaptureRequest.SENSOR_EXPOSURE_TIME, targetExp);
            Range<Integer>[] fps = characteristics.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES);
            if (fps != null && fps.length != 0) {
                Range<Integer> widest = fps[0];
                for (Range<Integer> candidate : fps) {
                    if (candidate.getUpper() - candidate.getLower() > widest.getUpper() - widest.getLower())
                        widest = candidate;
                }
                d.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, widest);
            }
            d.addTarget(yuvReader.getSurface()); // Decision targets ONLY the configured YUV companion.
            info("F200_DECISION_START", "camera=" + activeCameraId + " ISO=" + minIso
                    + " exposureNs=" + targetExp + " module=74 YUV_only");
            activeSession.setRepeatingRequest(d.build(), new CameraCaptureSession.CaptureCallback() {
                @Override public void onCaptureCompleted(CameraCaptureSession s,
                        CaptureRequest request, TotalCaptureResult result) {
                    if (decisionPending && generation == captureGeneration)
                        finishDecision(generation, "result frame=" + result.getFrameNumber());
                }
                @Override public void onCaptureFailed(CameraCaptureSession s,
                        CaptureRequest request, android.hardware.camera2.CaptureFailure failure) {
                    if (decisionPending && generation == captureGeneration)
                        info("F200_DECISION_FAILED", "reason=" + failure.getReason());
                }
            }, worker);
            worker.postDelayed(() -> {
                if (decisionPending && generation == captureGeneration && captureInFlight)
                    finishDecision(generation, "timeout 2000ms; try still anyway");
            }, 2000);
        } catch (Exception e) {
            decisionPending = false;
            captureInFlight = false;
            fail("F200_DECISION_EXCEPTION", e);
            if (session != null) startPreview(false);
        }
    }

    private void finishDecision(int generation, String reason) {
        if (!decisionPending || !captureInFlight || generation != captureGeneration) return;
        decisionPending = false;
        info("F200_DECISION_DONE", reason);
        try {
            session.stopRepeating(); // Do not resume normal RAW preview until still sequence ends.
            submitStill(generation);
        } catch (Exception e) {
            fail("F200_STOP_PREVIEW_FAILED", e);
            captureInFlight = false;
            if (session != null) startPreview(false);
        }
    }

    private void submitStill(int generation) {
        if (session == null || device == null) {
            info("CAPTURE_REFUSED", "Camera disconnected before still submission");
            captureInFlight = false;
            return;
        }
        try {
            CaptureRequest.Builder b = newBuilder(CameraDevice.TEMPLATE_STILL_CAPTURE);
            addRequestKeys(b);
            addStillKeys(b);
            b.addTarget(rawReader.getSurface());
            b.addTarget(fullReader.getSurface());
            session.capture(b.build(), new CameraCaptureSession.CaptureCallback() {
                @Override public void onCaptureCompleted(CameraCaptureSession s,
                         CaptureRequest request, TotalCaptureResult result) {
                    lastStillResult.set(result);
                    info("CAPTURE_RESULT", "frame=" + result.getFrameNumber()
                            + " sensorTimestamp=" + result.get(CaptureResult.SENSOR_TIMESTAMP)
                            + " NR=" + result.get(CaptureResult.NOISE_REDUCTION_MODE)
                            + " EDGE=" + result.get(CaptureResult.EDGE_MODE));
                    logResultEcho(result);
                    saveCalibration(result);
                }
                @Override public void onCaptureFailed(CameraCaptureSession s,
                         CaptureRequest request, android.hardware.camera2.CaptureFailure failure) {
                    info("CAPTURE_FAILED", "reason=" + failure.getReason());
                    captureInFlight = false;
                }
                @Override public void onCaptureSequenceCompleted(CameraCaptureSession s,
                        int sequenceId, long frameNumber) {
                    info("STILL_SEQUENCE_COMPLETE", "sequence=" + sequenceId + " frame=" + frameNumber);
                    if (active200 && device != null && session != null) startPreview(false);
                }
                @Override public void onCaptureSequenceAborted(CameraCaptureSession s, int sequenceId) {
                    info("STILL_SEQUENCE_ABORTED", "sequence=" + sequenceId);
                    captureInFlight = false;
                    if (active200 && device != null && session != null) startPreview(false);
                }
            }, worker);
            info(active200 ? "CAPTURE_200_SUBMITTED" : "CAPTURE_50_SUBMITTED",
                    "RAW full=" + activeFullWidth + "x" + activeFullHeight + " camera=" + activeCameraId);
        } catch (Exception e) {
            captureInFlight = false;
            fail("CAPTURE_SUBMIT_FAILED", e);
            if (active200 && session != null) startPreview(false);
        }
    }

    private void onFullRaw(ImageReader reader) {
        Image image = null;
        try {
            image = reader.acquireNextImage();
            if (image == null) return;
            final Image held = image;
            image = null;
            ++capturedImages;
            info("FULLRES_RAW_RECEIVED", "count=" + capturedImages +
                    " width=" + held.getWidth() + " height=" + held.getHeight() +
                    " format=" + held.getFormat() + " ts=" + held.getTimestamp());
            try {
                HardwareBuffer hb = held.getHardwareBuffer();
                if (hb != null) {
                    info("FULLRES_HWBUFFER", "w=" + hb.getWidth() + " h=" + hb.getHeight() +
                            " fmt=" + hb.getFormat() + " layers=" + hb.getLayers() +
                            " usage=" + hb.getUsage());
                    hb.close();
                } else { info("FULLRES_HWBUFFER", "null"); }
            } catch (Exception e) { info("FULLRES_HWBUFFER_ERROR", e.toString()); }
            // Capture result may arrive after the ImageReader callback.
            worker.postDelayed(() -> saveOrInspect(held, 0), 400);
        } catch (Exception e) { fail("FULLRES_IMAGE_ERROR", e); }
        finally { if (image != null) image.close(); }
    }

    // DngCreator sometimes uses CaptureResult.BLACK_LEVEL_PATTERN=0 for 200 MP even
    // though the V2547A F200 stream contains 10-bit values with black about 64.
    // Patch TIFF/DNG BlackLevel metadata only; do NOT change Bayer pixel data.
    // Do not alter the RGGB CFA tag: test previews of both F200 frames were natural
    // with RGGB, whereas trying GRBG on the F35 200MP sample made it pink.
    private static byte[] readDngBytes(FileDescriptor fd, int length, long offset) throws Exception {
        byte[] data = new byte[length];
        int done = 0;
        while (done < length) {
            int n = Os.pread(fd, data, done, length - done, offset + done);
            if (n <= 0) throw new IllegalStateException("TIFF short read at " + (offset + done));
            done += n;
        }
        return data;
    }
    private static void writeDngBytes(FileDescriptor fd, byte[] data, long offset) throws Exception {
        int done = 0;
        while (done < data.length) {
            int n = Os.pwrite(fd, data, done, data.length - done, offset + done);
            if (n <= 0) throw new IllegalStateException("TIFF short write at " + (offset + done));
            done += n;
        }
    }
    private void fix200BlackLevel(ContentResolver cr, Uri uri) throws Exception {
        try (ParcelFileDescriptor pfd = cr.openFileDescriptor(uri, "rw")) {
            if (pfd == null) throw new IllegalStateException("Could not reopen DNG for metadata fix");
            FileDescriptor fd = pfd.getFileDescriptor();
            byte[] header = readDngBytes(fd, 8, 0);
            boolean littleEndian = header[0] == 'I' && header[1] == 'I';
            if (!littleEndian && !(header[0] == 'M' && header[1] == 'M'))
                throw new IllegalArgumentException("Not a TIFF header");
            ByteOrder order = littleEndian ? ByteOrder.LITTLE_ENDIAN : ByteOrder.BIG_ENDIAN;
            ByteBuffer h = ByteBuffer.wrap(header).order(order);
            if (Short.toUnsignedInt(h.getShort(2)) != 42)
                throw new IllegalArgumentException("Only classic TIFF DNG supported");
            long ifd = Integer.toUnsignedLong(h.getInt(4));
            if (ifd < 8 || ifd > 64L * 1024 * 1024)
                throw new IllegalArgumentException("Invalid TIFF IFD offset=" + ifd);
            ByteBuffer nTag = ByteBuffer.wrap(readDngBytes(fd, 2, ifd)).order(order);
            int count = Short.toUnsignedInt(nTag.getShort());
            if (count < 1 || count > 4096)
                throw new IllegalArgumentException("Invalid TIFF tag count=" + count);
            for (int i = 0; i < count; i++) {
                byte[] entry = readDngBytes(fd, 12, ifd + 2L + i * 12L);
                ByteBuffer t = ByteBuffer.wrap(entry).order(order);
                int tag = Short.toUnsignedInt(t.getShort(0));
                if (tag != 50714) continue; // DNG BlackLevel
                int type = Short.toUnsignedInt(t.getShort(2));
                long elements = Integer.toUnsignedLong(t.getInt(4));
                long offset = Integer.toUnsignedLong(t.getInt(8));
                if (type != 5 || elements != 4)
                    throw new IllegalArgumentException("Unexpected DNG BlackLevel type=" + type + " count=" + elements);
                byte[] values = readDngBytes(fd, 32, offset);
                ByteBuffer b = ByteBuffer.wrap(values).order(order);
                int[] numerator = new int[4];
                long[] denominator = new long[4];
                for (int k = 0; k < 4; k++) {
                    numerator[k] = b.getInt(k * 8);
                    denominator[k] = Integer.toUnsignedLong(b.getInt(k * 8 + 4));
                    if (denominator[k] == 0 || denominator[k] > 1000000)
                        throw new IllegalArgumentException("Invalid BlackLevel denominator=" + denominator[k]);
                }
                boolean zero = true;
                for (int k = 0; k < 4; k++) if (numerator[k] != 0) zero = false;
                if (!zero) {
                    info("F200_BLACKLEVEL_ALREADY_SET", "value=" + numerator[0] + "/" + denominator[0]);
                    return;
                }
                for (int k = 0; k < 4; k++)
                    b.putInt(k * 8, Math.toIntExact(64L * denominator[k]));
                writeDngBytes(fd, values, offset);
                byte[] verify = readDngBytes(fd, 32, offset);
                if (!Arrays.equals(values, verify))
                    throw new IllegalStateException("BlackLevel metadata write verification failed");
                info("F200_DNG_BLACKLEVEL_FIXED", "0 -> 64/1023; CFA=RGGB preserved; RAW pixels unchanged");
                return;
            }
            throw new IllegalStateException("DNG BlackLevel tag not found");
        }
    }

    private void saveOrInspect(Image image, int metadataAttempts) {
        // Unlike 50 MP, full 200 MP RAW metadata can arrive well after the large Image.
        // Keep the Image open until its capture result arrives, within a bounded wait.
        if (lastStillResult.get() == null && metadataAttempts < 60 && session != null) {
            worker.postDelayed(() -> saveOrInspect(image, metadataAttempts + 1), 200);
            return;
        }
        try {
            try {
                Image.Plane[] planes = image.getPlanes();
                if (planes.length > 0) {
                    info("RAW_PLANE", "rowStride=" + planes[0].getRowStride() +
                            " pixelStride=" + planes[0].getPixelStride() +
                            " remaining=" + planes[0].getBuffer().remaining());
                }
            } catch (Exception e) {
                info("RAW_PLANE_UNAVAILABLE", "GPU_DATA_BUFFER path: " + e.getClass().getSimpleName());
            }
            TotalCaptureResult result = lastStillResult.get();
            if (result == null || characteristics == null) {
                info("DNG_NOT_READY", "Capture result absent after wait (attempts="
                        + metadataAttempts + "); RAW image released");
                return;
            }
            info("BLOCK_TEST", variantLabel() + " " + analyzeRaw(image));
            ContentValues values = new ContentValues();
            String file = "XLAB_" + activeCameraId + (active200 ? "_F200_" : "_H50_")
                    + variantLabel() + "_" + System.currentTimeMillis() + ".dng";
            values.put(MediaStore.Images.Media.DISPLAY_NAME, file);
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/x-adobe-dng");
            values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_DCIM + "/XeniusFullRes");
            values.put(MediaStore.Images.Media.IS_PENDING, 1);
            ContentResolver cr = getContentResolver();
            Uri uri = cr.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new IllegalStateException("MediaStore.insert returned null");
            try {
                try (OutputStream out = cr.openOutputStream(uri); DngCreator dng = new DngCreator(characteristics, result)) {
                    if (out == null) throw new IllegalStateException("MediaStore OutputStream null");
                    dng.setOrientation(captureExifOrientation);
                    dng.writeImage(out, image);
                }
                if (active200) {
                    try { fix200BlackLevel(cr, uri); }
                    catch (Exception metadataError) {
                        // Keep the RAW rather than deleting an otherwise successful capture.
                        info("F200_BLACKLEVEL_FIX_FAILED", metadataError.toString());
                        Log.e(TAG, "F200 DNG metadata fix failed", metadataError);
                    }
                }
                ContentValues finish = new ContentValues();
                finish.put(MediaStore.Images.Media.IS_PENDING, 0);
                cr.update(uri, finish, null, null);
                info("DNG_WRITTEN", "file=" + file + " orientation=" + captureExifOrientation
                        + " mode=" + (active200 ? "F200" : "H50")
                        + " raw=" + image.getWidth() + "x" + image.getHeight());
            } catch (Exception e) {
                cr.delete(uri, null, null);
                throw e;
            }
        } catch (Exception e) {
            fail("DNG_WRITE_UNSUPPORTED", e);
            info("NEXT_DIAGNOSTIC", "HardwareBuffer NDK lock/copy needed if GPU-only RAW plane blocked");
        } finally {
            image.close();
            captureInFlight = false;
        }
    }

    // ---------------- P31: block test, result echo, camera dump, log save ----------------

    /** Classifies the RAW mosaic from a 1024x1024 centre crop.
     *  Horizontal/vertical neighbour differences grouped by position inside a 4-pixel period:
     *  Bayer: every neighbour pair is two different colours -> all phases similar.
     *  Quad 2x2: pairs inside a block (phase 0,2) are same colour -> small; across (1,3) large.
     *  4x4: phases 0,1,2 inside the block small, phase 3 large. */
    private String analyzeRaw(Image image) {
        try {
            Image.Plane[] planes = image.getPlanes();
            if (planes.length == 0) return "no planes";
            Image.Plane p = planes[0];
            ByteBuffer buf = p.getBuffer().duplicate().order(ByteOrder.LITTLE_ENDIAN);
            int rs = p.getRowStride(), ps = p.getPixelStride();
            if (ps != 2) return "pixelStride=" + ps + " (expected 2)";
            int w = image.getWidth(), h = image.getHeight();
            int S = Math.min(1024, Math.min(w, h) - 16);
            int x0 = (w / 2 - S / 2) & ~7, y0 = (h / 2 - S / 2) & ~7;
            double[] dh = new double[4], dv = new double[4];
            double[][] mean = new double[4][4];
            long n = 0;
            for (int y = y0; y < y0 + S; y++) {
                int row = y * rs, row2 = (y + 1) * rs;
                for (int x = x0; x < x0 + S; x++) {
                    int v = buf.getShort(row + x * 2) & 0xffff;
                    mean[y & 3][x & 3] += v;
                    dh[x & 3] += Math.abs(v - (buf.getShort(row + (x + 1) * 2) & 0xffff));
                    dv[y & 3] += Math.abs(v - (buf.getShort(row2 + x * 2) & 0xffff));
                    n++;
                }
            }
            double q = n / 16.0;
            double total = 0;
            for (int i = 0; i < 4; i++) for (int j = 0; j < 4; j++) total += mean[i][j];
            double avg = total / n;
            StringBuilder m = new StringBuilder("means4x4=[");
            for (int i = 0; i < 4; i++) {
                m.append(i == 0 ? "" : " | ");
                for (int j = 0; j < 4; j++) m.append(String.format(Locale.US, j == 0 ? "%.0f" : " %.0f", mean[i][j] / q));
            }
            m.append("]");
            double r2h = (dh[1] + dh[3]) / Math.max(1e-9, dh[0] + dh[2]);
            double r2v = (dv[1] + dv[3]) / Math.max(1e-9, dv[0] + dv[2]);
            double r4h = dh[3] / Math.max(1e-9, (dh[0] + dh[1] + dh[2]) / 3);
            double r4v = dv[3] / Math.max(1e-9, (dv[0] + dv[1] + dv[2]) / 3);
            String verdict;
            String light = String.format(Locale.US, "mean=%.0f", avg);
            if (avg < 64 + 40 && avg < 300) light += " TOO DARK (verdict unreliable, aim at a bright scene)";
            if (r4h > 1.5 && r4v > 1.5 && dh[1] < 1.3 * dh[0]) verdict = "4x4 BLOCKS (unremosaiced!)";
            else if (r2h > 1.5 && r2v > 1.5) verdict = "QUAD 2x2 (unremosaiced!)";
            else verdict = "BAYER (remosaiced)";
            return String.format(Locale.US, "%s  %s  %dx%d r2=%.2f/%.2f r4=%.2f/%.2f dH=[%.1f %.1f %.1f %.1f] %s",
                    verdict, light, w, h, r2h, r2v, r4h, r4v,
                    dh[0] / q / 4, dh[1] / q / 4, dh[2] / q / 4, dh[3] / q / 4, m);
        } catch (Exception e) {
            return "unavailable (" + e.getClass().getSimpleName() + ") - send the DNG instead";
        }
    }

    /** Logs result keys that show whether the HAL accepted / echoed our test keys (big arrays: length only). */
    private void logResultEcho(TotalCaptureResult result) {
        info("RESULT_ECHO", shortEcho(result));
    }

    private String shortEcho(CaptureResult result) {
        if (result == null) return "(no result)";
        try {
            StringBuilder sb = new StringBuilder();
            for (CaptureResult.Key<?> k : result.getKeys()) {
                String nm = k.getName();
                String low = nm.toLowerCase(Locale.US);
                if (low.contains("remosaic") || low.contains("xcfa") || low.contains("sensormode")
                        || low.contains("highres") || low.contains("ultra") || low.contains("qcfa")
                        || low.contains("binning") || low.contains("pixelmode") || low.contains("pixel_mode")) {
                    Object v = result.get(k);
                    String vs = (v != null && v.getClass().isArray() && java.lang.reflect.Array.getLength(v) > 16)
                            ? "[" + java.lang.reflect.Array.getLength(v) + " values]" : fmt(v);
                    sb.append(nm).append('=').append(vs).append("  ");
                }
            }
            return sb.length() == 0 ? "(no matching result keys)" : sb.toString();
        } catch (Exception e) { return "echo error " + e; }
    }

    /** Saves the per-frame remosaic calibration blobs (EEPROM / OTP) once per app run. */
    private void saveCalibration(TotalCaptureResult result) {
        if (calibrationSaved) return;
        try {
            int saved = 0;
            for (CaptureResult.Key<?> k : result.getKeys()) {
                String low = k.getName().toLowerCase(Locale.US);
                if (!(low.contains("remosaic") || low.contains("otp") || low.contains("eeprom"))) continue;
                Object v = result.get(k);
                if (!(v instanceof byte[]) || ((byte[]) v).length < 64) continue;
                String name = "XLAB_cam" + activeCameraId + "_" + k.getName().replace('.', '_') + ".bin";
                writeBinary(name, (byte[]) v);
                info("CALIBRATION_SAVED", k.getName() + " " + ((byte[]) v).length + " bytes -> Download/XeniusLab/" + name);
                saved++;
            }
            if (saved > 0) calibrationSaved = true;
        } catch (Exception e) { info("CALIBRATION_SAVE_ERROR", e.toString()); }
    }

    private static String fmt(Object o) {
        if (o == null) return "null";
        if (o.getClass().isArray()) {
            int len = java.lang.reflect.Array.getLength(o);
            StringBuilder sb = new StringBuilder("[");
            for (int i = 0; i < Math.min(len, 512); i++) {
                if (i > 0) sb.append(", ");
                sb.append(fmt(java.lang.reflect.Array.get(o, i)));
            }
            if (len > 512) sb.append(", ... (").append(len).append(" total)");
            return sb.append(']').toString();
        }
        return String.valueOf(o);
    }

    private void dumpCameras() {
        StringBuilder sb = new StringBuilder();
        sb.append("Xenius Stream Lab P33 camera dump\nmodel=").append(Build.MODEL)
                .append(" device=").append(Build.DEVICE).append(" build=").append(Build.DISPLAY)
                .append(" sdk=").append(Build.VERSION.SDK_INT).append("\n");
        try { sb.append("listed ids=").append(Arrays.toString(cameraManager.getCameraIdList())).append("\n"); }
        catch (Exception e) { sb.append("id list error ").append(e).append("\n"); }
        sb.append("key40=").append(gate.peekSafe()).append(" ").append(gate.state()).append("\n");
        int found = 0;
        for (int i = 0; i < 16; i++) {
            String id = Integer.toString(i);
            CameraCharacteristics c;
            try { c = cameraManager.getCameraCharacteristics(id); }
            catch (Exception e) { continue; }
            found++;
            sb.append("\n================ CAMERA ").append(id).append(" ================\n");
            try {
                android.hardware.camera2.params.StreamConfigurationMap map =
                        c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
                dumpMap(sb, "streamMap", map);
                if (Build.VERSION.SDK_INT >= 31) {
                    dumpMap(sb, "streamMap MAX_RES",
                            c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP_MAXIMUM_RESOLUTION));
                    sb.append("binningFactor=").append(c.get(CameraCharacteristics.SENSOR_INFO_BINNING_FACTOR)).append("\n");
                }
            } catch (Exception e) { sb.append("stream map error ").append(e).append("\n"); }
            sb.append("--- characteristics (all keys incl. vendor) ---\n");
            for (CameraCharacteristics.Key<?> k : c.getKeys()) {
                String v;
                try { v = fmt(c.get(k)); } catch (Exception e) { v = "<" + e.getClass().getSimpleName() + ">"; }
                if (v.length() > 6000) v = v.substring(0, 6000) + " ...(cut)";
                sb.append(k.getName()).append(" = ").append(v).append("\n");
            }
            sb.append("--- available capture request keys ---\n");
            try { for (CaptureRequest.Key<?> k : c.getAvailableCaptureRequestKeys()) sb.append(k.getName()).append("\n"); }
            catch (Exception e) { sb.append("error ").append(e).append("\n"); }
            sb.append("--- available session keys ---\n");
            try { for (CaptureRequest.Key<?> k : c.getAvailableSessionKeys()) sb.append(k.getName()).append("\n"); }
            catch (Exception e) { sb.append("error ").append(e).append("\n"); }
            sb.append("--- available capture result keys ---\n");
            try { for (CaptureResult.Key<?> k : c.getAvailableCaptureResultKeys()) sb.append(k.getName()).append("\n"); }
            catch (Exception e) { sb.append("error ").append(e).append("\n"); }
            try { sb.append("physical ids=").append(c.getPhysicalCameraIds()).append("\n"); }
            catch (Exception ignored) { }
        }
        String name = "XLAB_camdump_" + System.currentTimeMillis() + ".txt";
        writeText(name, sb.toString());
        info("CAMERA_DUMP", found + " cameras, " + sb.length() + " chars -> Download/XeniusLab/" + name);
    }

    private static void dumpMap(StringBuilder sb, String label,
                                android.hardware.camera2.params.StreamConfigurationMap map) {
        sb.append(label).append(":");
        if (map == null) { sb.append(" null\n"); return; }
        sb.append("\n");
        for (int f : map.getOutputFormats()) {
            android.util.Size[] sizes = map.getOutputSizes(f);
            sb.append("  fmt 0x").append(Integer.toHexString(f)).append(": ")
                    .append(sizes == null ? "-" : Arrays.toString(sizes)).append("\n");
        }
        try {
            int[] in = map.getInputFormats();
            for (int f : in) sb.append("  input fmt 0x").append(Integer.toHexString(f)).append(": ")
                    .append(Arrays.toString(map.getInputSizes(f))).append("\n");
        } catch (Exception ignored) { }
    }

    private void saveLog() {
        final String[] text = new String[1];
        final Object lock = new Object();
        runOnUiThread(() -> { synchronized (lock) { text[0] = report.getText().toString(); lock.notifyAll(); } });
        synchronized (lock) {
            long end = SystemClock.uptimeMillis() + 2000;
            while (text[0] == null && SystemClock.uptimeMillis() < end) {
                try { lock.wait(200); } catch (InterruptedException ignored) { }
            }
        }
        if (text[0] == null) { info("LOG_SAVE_FAILED", "UI thread busy"); return; }
        String name = "XLAB_log_" + System.currentTimeMillis() + ".txt";
        writeText(name, text[0]);
        info("LOG_SAVED", "Download/XeniusLab/" + name);
    }

    private void writeText(String name, String text) {
        try {
            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
            v.put(MediaStore.MediaColumns.MIME_TYPE, "text/plain");
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/XeniusLab");
            ContentResolver cr = getContentResolver();
            Uri uri = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
            if (uri == null) throw new IllegalStateException("MediaStore.insert returned null");
            try (OutputStream out = cr.openOutputStream(uri)) {
                out.write(text.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            }
        } catch (Exception e) { fail("WRITE_TEXT_FAILED", e); }
    }

    private void writeBinary(String name, byte[] data) {
        try {
            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
            v.put(MediaStore.MediaColumns.MIME_TYPE, "application/octet-stream");
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/XeniusLab");
            ContentResolver cr = getContentResolver();
            Uri uri = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
            if (uri == null) throw new IllegalStateException("MediaStore.insert returned null");
            try (OutputStream out = cr.openOutputStream(uri)) { out.write(data); }
        } catch (Exception e) { fail("WRITE_BINARY_FAILED", e); }
    }

    // ---------------- P32: forceSensorMode auto sweep (plain session, RAW stream only, no key40) ----------------
    private static final int SWEEP_MAX = 40;
    private static final String SWEEP_ID = "5";
    private CameraDevice sweepDevice;
    private CameraCaptureSession sweepSession;
    private ImageReader sweepReader;
    private boolean sweeping = false;
    private int sweepModeNow = -1, sweepFrames = 0, sweepGen = 0, sweepReportedGen = -1;
    private volatile CaptureResult sweepLastResult;
    private int sweepRetries = 0;
    private boolean sweepCrashed = false;
    private final List<Integer> sweepCrashers = new ArrayList<>();

    /** After a fatal HAL error the camera service restarts and the id is "unknown" for a while. */
    private void waitForCameraThen(Runnable next, int seconds) {
        if (!sweeping) return;
        try {
            cameraManager.getCameraCharacteristics(SWEEP_ID);
            info("SWEEP_CAMERA_BACK", "camera " + SWEEP_ID + " available again after ~" + seconds + " s");
            worker.postDelayed(next, 2500);
        } catch (Exception e) {
            if (seconds >= 45) {
                sweeping = false;
                info("SWEEP_ABORT", "camera " + SWEEP_ID + " did not come back within 45 s - reboot/try later");
                return;
            }
            worker.postDelayed(() -> waitForCameraThen(next, seconds + 1), 1000);
        }
    }

    private void startSweep() {
        if (device != null || session != null || openPending || sweeping) {
            info("SWEEP_REFUSED", "Close the camera first (or a sweep is already running)");
            return;
        }
        sweeping = true;
        sweepRetries = 0;
        sweepCrashers.clear();
        info("SWEEP_START", "camera " + SWEEP_ID + ", forceSensorMode " + fsmValue + ".." + SWEEP_MAX
                + ", one RAW frame each. Keep the phone still on a bright, detailed scene. Close = stop.");
        sweepNext(fsmValue);
    }

    private void sweepNext(int n) {
        if (!sweeping) return;
        if (n > SWEEP_MAX) {
            sweeping = false;
            info("SWEEP_DONE", "modes that crashed the camera: " + sweepCrashers + " - tap Save this log");
            return;
        }
        sweepCrashed = false;
        sweepModeNow = n;
        sweepFrames = 0;
        sweepLastResult = null;
        final int gen = ++sweepGen;
        try {
            CameraCharacteristics c = cameraManager.getCameraCharacteristics(SWEEP_ID);
            android.hardware.camera2.params.StreamConfigurationMap map =
                    c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
            android.util.Size[] sizes = map.getOutputSizes(ImageFormat.RAW_SENSOR);
            android.util.Size size = sizes[0];
            for (android.util.Size z : sizes) if (z.getWidth() * (long) z.getHeight() > size.getWidth() * (long) size.getHeight()) size = z;
            sweepReader = ImageReader.newInstance(size.getWidth(), size.getHeight(), ImageFormat.RAW_SENSOR, 4);
            sweepReader.setOnImageAvailableListener(r -> onSweepImage(r, n, gen), worker);
            cameraManager.openCamera(SWEEP_ID, new CameraDevice.StateCallback() {
                @Override public void onOpened(CameraDevice d) { sweepDevice = d; configureSweep(d, n, gen); }
                @Override public void onDisconnected(CameraDevice d) { info("SWEEP_MODE", n + " DISCONNECTED"); d.close(); }
                @Override public void onError(CameraDevice d, int e) {
                    info("SWEEP_MODE", n + " CAMERA_ERROR " + e + (e == 4 ? " (fatal: HAL restarts, waiting)" : ""));
                    sweepCrashed = true;
                    if (!sweepCrashers.contains(n)) sweepCrashers.add(n);
                    sweepReportedGen = gen;
                    d.close();
                }
                @Override public void onClosed(CameraDevice d) {
                    if (sweepDevice == d) sweepDevice = null;
                    sweepSession = null;
                    if (sweepReader != null) { sweepReader.close(); sweepReader = null; }
                    if (!sweeping) return;
                    sweepRetries = 0;
                    if (sweepCrashed) waitForCameraThen(() -> sweepNext(n + 1), 0);
                    else worker.postDelayed(() -> sweepNext(n + 1), 300);
                }
            }, worker);
            worker.postDelayed(() -> {
                if (sweeping && gen == sweepGen && sweepReportedGen != gen) {
                    info("SWEEP_MODE", n + " TIMEOUT (no RAW frame in 6 s) echo=" + shortEcho(sweepLastResult));
                    sweepReportedGen = gen;
                    sweepClose();
                }
            }, 6000);
        } catch (Exception e) {
            if (sweepReader != null) { sweepReader.close(); sweepReader = null; }
            if (sweepRetries < 3) {
                sweepRetries++;
                info("SWEEP_WAIT", n + " camera not available (" + e.getClass().getSimpleName()
                        + "), waiting to retry " + sweepRetries + "/3");
                waitForCameraThen(() -> sweepNext(n), 0);
            } else {
                sweepRetries = 0;
                info("SWEEP_MODE", n + " OPEN_FAILED after retries " + e);
                worker.postDelayed(() -> sweepNext(n + 1), 300);
            }
        }
    }

    private void configureSweep(CameraDevice d, int n, int gen) {
        try {
            CaptureRequest.Builder b = d.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
            List<String> log = new ArrayList<>();
            tryKey(b, FSM, n, log);
            ArrayList<OutputConfiguration> outs = new ArrayList<>();
            outs.add(new OutputConfiguration(sweepReader.getSurface()));
            SessionConfiguration cfg = new SessionConfiguration(SessionConfiguration.SESSION_REGULAR, outs, cameraExecutor,
                    new CameraCaptureSession.StateCallback() {
                        @Override public void onConfigured(CameraCaptureSession s) {
                            sweepSession = s;
                            try {
                                b.addTarget(sweepReader.getSurface());
                                s.setRepeatingRequest(b.build(), new CameraCaptureSession.CaptureCallback() {
                                    @Override public void onCaptureCompleted(CameraCaptureSession ss,
                                            CaptureRequest rq, TotalCaptureResult r) { sweepLastResult = r; }
                                }, worker);
                            } catch (Exception e) {
                                info("SWEEP_MODE", n + " REPEATING_FAILED " + e);
                                sweepReportedGen = gen;
                                sweepClose();
                            }
                        }
                        @Override public void onConfigureFailed(CameraCaptureSession s) {
                            info("SWEEP_MODE", n + " SESSION_REFUSED " + log);
                            sweepReportedGen = gen;
                            sweepClose();
                        }
                    });
            cfg.setSessionParameters(b.build());
            d.createCaptureSession(cfg);
        } catch (Exception e) {
            info("SWEEP_MODE", n + " CONFIG_EXCEPTION " + e);
            sweepReportedGen = gen;
            sweepClose();
        }
    }

    private void onSweepImage(ImageReader r, int n, int gen) {
        Image img = null;
        try {
            img = r.acquireLatestImage();
            if (img == null || gen != sweepGen || sweepReportedGen == gen) return;
            if (++sweepFrames < 6) return;   // let AE settle a little
            sweepReportedGen = gen;
            info("SWEEP_MODE", n + " frame=" + img.getWidth() + "x" + img.getHeight() + " "
                    + analyzeRaw(img) + " echo=" + shortEcho(sweepLastResult));
            img.close();
            img = null;
            sweepClose();
        } catch (Exception e) {
            info("SWEEP_MODE", n + " IMAGE_ERROR " + e);
        } finally { if (img != null) img.close(); }
    }

    private void sweepClose() {
        try { if (sweepSession != null) sweepSession.close(); } catch (Exception ignored) { }
        sweepSession = null;
        if (sweepDevice != null) sweepDevice.close();
        else if (sweeping) { final int next = sweepModeNow + 1; worker.postDelayed(() -> sweepNext(next), 300); }
    }

    private void cleanupReaders() {
        session = null;
        previewSwitched = false;
        lastStillResult.set(null);
        captureInFlight = false;
        decisionPending = false;
        ++captureGeneration;
        if (rawReader != null) { rawReader.close(); rawReader = null; }
        if (fullReader != null) { fullReader.close(); fullReader = null; }
        if (yuvReader != null) { yuvReader.close(); yuvReader = null; }
    }
    private void closeCamera() {
        if (sweeping) {
            sweeping = false;
            info("SWEEP_STOPPED", "at forceSensorMode=" + sweepModeNow);
            try { if (sweepSession != null) sweepSession.close(); } catch (Exception ignored) { }
            if (sweepDevice != null) sweepDevice.close();
            return;
        }
        info("CLOSE_REQUESTED", "camera=" + activeCameraId + " pending=" + openPending);
        if (session != null) { session.close(); session = null; }
        if (device != null) { device.close(); /* gate restored in onClosed */ }
        else if (!openPending) { cleanupReaders(); gate.restore(); }
        else { info("CLOSE_DEFERRED", "waiting for camera open/onError callback"); }
    }
    @Override protected void onDestroy() {
        if (orientationListener != null) orientationListener.disable();
        worker.post(this::closeCamera);
        super.onDestroy();
    }

    private final class VivoGate {
        private Object instance;
        private Method getInfo, setValue;
        private Integer previous;
        private boolean owned;
        private final String PENDING = "gate_owned";
        private final String BEFORE = "gate_previous";
        private void init() throws Exception {
            if (instance != null) return;
            Class<?> cls = Class.forName("android.hardware.vivocamera.VivoCameraManager");
            instance = cls.getMethod("getInstance").invoke(null);
            getInfo = cls.getMethod("getInfo", int.class);
            setValue = cls.getMethod("setValue", int.class, int.class);
        }
        int peek() throws Exception {
            init();
            Object value = getInfo.invoke(instance, 40);
            return ((Number)value).intValue();
        }
        String peekSafe() {
            try { return Integer.toString(peek()); }
            catch (Exception e) { return "unreadable"; }
        }
        String state() {
            return "key1=" + peekIdSafe(1) + " key33=" + peekIdSafe(33) + " key40=" + peekIdSafe(40);
        }
        String peekIdSafe(int id) {
            try { init(); return Integer.toString(((Number)getInfo.invoke(instance, id)).intValue()); }
            catch (Exception e) { return "?"; }
        }
        void recoverIfLeftActive() {
            if (!getPreferences(Context.MODE_PRIVATE).getBoolean(PENDING, false)) return;
            int prev = getPreferences(Context.MODE_PRIVATE).getInt(BEFORE, -1);
            try {
                if (prev >= 0 && peek() == 1) {
                    setValue.invoke(instance, 40, prev);
                    info("VIVO_GATE_RECOVERED", "restored=" + prev);
                }
                getPreferences(Context.MODE_PRIVATE).edit().putBoolean(PENDING, false).apply();
            } catch (Exception e) { fail("VIVO_GATE_RECOVERY_FAILED", e); }
        }
        boolean acquire() {
            try {
                previous = peek();
                if (previous < 0) throw new IllegalStateException("Cannot read previous key40");
                getPreferences(Context.MODE_PRIVATE).edit()
                        .putInt(BEFORE, previous).putBoolean(PENDING, true).commit();
                setValue.invoke(instance, 40, 1);
                // The vendor provider update is asynchronous on some firmware.
                SystemClock.sleep(200);
                if (peek() != 1) throw new IllegalStateException("key40 did not become 1");
                owned = true;
                info("VIVO_GATE_ACQUIRED", "before=" + previous + " now=" + peek());
                info("VIVO_GATE_STATE", "stage=acquired " + state());
                return true;
            } catch (Exception e) {
                fail("VIVO_GATE_ACQUIRE_FAILED", e);
                restore();
                return false;
            }
        }
        void restore() {
            if (previous == null) return;
            try {
                init();
                setValue.invoke(instance, 40, previous);
                SystemClock.sleep(100);
                info("VIVO_GATE_RESTORED", "expected=" + previous + " actual=" + peekSafe());
                info("VIVO_GATE_STATE", "stage=restored " + state());
                getPreferences(Context.MODE_PRIVATE).edit().putBoolean(PENDING, false).commit();
                owned = false;
                previous = null;
            } catch (Exception e) { fail("VIVO_GATE_RESTORE_FAILED", e); }
        }
    }
}
