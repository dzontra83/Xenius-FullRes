# Xenius P29 — TWO F200 frames in a queued Camera2 burst

Built from the already-tested P27 capture protocol (50/200 MP single RAW frames, valid TIFF BlackLevel=64 and DNG Orientation). V2547A has now confirmed 2/2 200MP RAW with per-frame results on both cameras. This version adds a **two-frame RAW-to-DNG save test**; **NO HDR+ merge is performed**.

1. Close regular GCam and open the `Xenius FullRes P28` debug app.
2. `Open F85 / 200 MP (ID 5)`, wait for `FULLRES_SESSION_CONFIGURED`.
3. Press `P29 SAVE: 2 × 200 MP RAW burst (F85/F35)` **once** and let it complete. Prefer a well-lit, static subject; avoid repeated taps while processing.
4. Expect `F200_DECISION_DONE`, `BURST_2_SUBMITTED`, 2× `BURST_2_RESULT`, 2× `BURST_2_RAW_IMAGE`, 2× `BURST_2_FRAME_MATCHED`, 2× `BURST_2_DNG_WRITTEN`, and `BURST_2_FINAL saved=2/2`.
5. Files are named `XENIUS_5_F200_B2_F1_...dng` and `...F2_...dng` under `DCIM/XeniusFullRes`.
6. Close camera to restore Vivo key40. Do not use stock camera while test app holds this gate.

A successful result proves **two matched fullsize still buffers**, not full optical 200MP resolution, not frame alignment, and definitely not GCam HDR+. To test F35 select `Open F35 / 200 MP (ID 3)` after closing F85.

The output remains 16-bit storage with 10-bit RAW values (black 64/white 1023) and CFA RGGB. The P27 post-save TIFF metadata correction is retained. 50MP and single 200MP buttons are retained unchanged.

### Implementation

- Queue exactly 2 still requests via `CameraCaptureSession.captureBurst` after one YUV decision frame.
- Unique Vivo requestId/frameFlag/globalCaptureId per still; tag each still as frame 1 or 2.
- Match each `Image.getTimestamp()` with `TotalCaptureResult.SENSOR_TIMESTAMP`. Never reuse the latest result for both frames.
- Process DNG writing on a **separate serial HandlerThread**, avoiding blocking Camera2 callbacks; keep two 383MiB RAW Images maximum at a time. Write no full-frame byte-array copies. Re-check RAW reader after each saved frame in case a callback was missed.
- Restore preview **only after burst sequence completed and both DNGs saved**.
- Timeout after 150 seconds; log diagnostic errors and preserve working P27 single capture route.

### Risks

Large memory footprint (2×382.5 MiB input + Android buffers). A hardware/firmware error can still disconnect the camera. For the first test do not take multiple consecutive bursts and close the app using the in-app button. The user V2547A has confirmed 2/2 burst delivery on F85 and F35; whether writing two large DNGs succeeds remains to be tested. P27 is the known working baseline.

This variant installs separately with package `com.xenius.fullresburstsave` so P27 and P28 are not overwritten.
