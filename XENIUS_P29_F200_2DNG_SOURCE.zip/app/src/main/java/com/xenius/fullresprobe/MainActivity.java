package com.xenius.fullresprobe;

import android.Manifest;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.ImageFormat;
import android.hardware.HardwareBuffer;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.CaptureResult;
import android.hardware.camera2.DngCreator;
import android.hardware.camera2.TotalCaptureResult;
import android.hardware.camera2.params.OutputConfiguration;
import android.hardware.camera2.params.SessionConfiguration;
import android.media.Image;
import android.media.ImageReader;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.system.Os;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.util.Log;
import android.util.Range;
import android.view.View;
import android.view.OrientationEventListener;
import android.view.Surface;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.OutputStream;
import java.io.FileDescriptor;
import java.nio.ByteOrder;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.HashMap;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Independent Camera2 experiment informed by publicly documented Vivo protocol.
 * Does not modify an existing GCam package and does not reuse RawR source code.
 * Capture is experimental: HAL may reject stream sizes, keys or DNG metadata.
 */
public final class MainActivity extends Activity {
    private static final String TAG = "XENIUS_P29";
    private static final int PERMISSION_REQUEST = 25;
    private static final int RAW_W = 4080, RAW_H_H85 = 3072, RAW_H_H35 = 3064;
    private static final int H_FULL_W = 8192, H_FULL_H = 6144;
    private static final int F_FULL_W = 16320, F_FULL_H_85 = 12288, F_FULL_H_35 = 12256;
    private static final int YUV_W = 640, YUV_H = 480;
    private HandlerThread workerThread;
    private Handler worker;
    private HandlerThread writerThread;
    private Handler fileWriter;
    private Executor cameraExecutor;
    private TextView report;
    private CameraManager cameraManager;
    private CameraDevice device;
    private CameraCaptureSession session;
    private ImageReader rawReader, fullReader, yuvReader;
    private CameraCharacteristics characteristics;
    private String activeCameraId;
    private int activePreviewHeight = RAW_H_H85;
    private int activeFullWidth = H_FULL_W, activeFullHeight = H_FULL_H;
    private boolean active200 = false;
    private boolean captureInFlight = false;
    private boolean decisionPending = false;
    private int captureGeneration = 0;
    private long previewExposureNs = 33333333L;
    private int capturedImages = 0;
    private volatile int deviceOrientationDegrees = -1;
    private OrientationEventListener orientationListener;
    private int captureExifOrientation = ExifInterface.ORIENTATION_NORMAL;
    private boolean openPending = false;
    private boolean previewSwitched = false;
    private final AtomicReference<TotalCaptureResult> lastStillResult = new AtomicReference<>();
    private final VivoGate gate = new VivoGate();
    // All collection mutations happen on the single Camera2 worker looper.
    // DNG writes happen on a dedicated serial writer to avoid blocking callbacks.
    private boolean burstActive = false;
    private boolean burstSequenceDone = false;
    private int burstResultsSeen = 0;
    private int burstImagesSeen = 0;
    private int burstSavesFinished = 0;
    private int burstSavesGood = 0;
    private int burstFailures = 0;
    private int burstWriterInflight = 0;
    private final Map<Long, Image> burstWaitingImages = new HashMap<>();
    private final Map<Long, TotalCaptureResult> burstWaitingResults = new HashMap<>();
    private final Map<Long, Integer> burstResultIndices = new HashMap<>();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        workerThread = new HandlerThread("xenius-p25-camera");
        workerThread.start();
        worker = new Handler(workerThread.getLooper());
        cameraExecutor = r -> worker.post(r);
        writerThread = new HandlerThread("xenius-p28-dng-writer");
        writerThread.start();
        fileWriter = new Handler(writerThread.getLooper());
        cameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(18, 16, 18, 16);
        addButton(root, "1. Check Vivo key40", () -> worker.post(this::checkGate));
        addButton(root, "Open H85 / 50 MP (ID 5)", () -> worker.post(() -> openMode("5", false)));
        addButton(root, "Open H35 / 50 MP (ID 3)", () -> worker.post(() -> openMode("3", false)));
        addButton(root, "Open F85 / 200 MP (ID 5)", () -> worker.post(() -> openMode("5", true)));
        addButton(root, "Open F35 / 200 MP (ID 3)", () -> worker.post(() -> openMode("3", true)));
        addButton(root, "Capture current lens / 50 or 200 MP", () -> worker.post(this::captureSelected));
        addButton(root, "P29 SAVE: 2 × 200 MP RAW to DNG (F85/F35)",
                () -> worker.post(this::captureTwo200));
        addButton(root, "Close camera / restore Vivo key40", () -> worker.post(this::closeCamera));
        report = new TextView(this);
        report.setTextSize(12);
        report.setTextIsSelectable(true);
        report.setText("P29: save TWO matched full-resolution 200 MP DNG files, 50/200 MP singles remain available. NOT HDR+.\n");
        ScrollView scroll = new ScrollView(this);
        scroll.addView(report);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
        orientationListener = new OrientationEventListener(this) {
            @Override public void onOrientationChanged(int orientation) {
                if (orientation != OrientationEventListener.ORIENTATION_UNKNOWN) {
                    deviceOrientationDegrees = ((orientation + 45) / 90 * 90) % 360;
                }
            }
        };
        if (orientationListener.canDetectOrientation()) orientationListener.enable();
        worker.post(gate::recoverIfLeftActive);
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, PERMISSION_REQUEST);
        }
    }

    private void addButton(LinearLayout parent, String title, Runnable action) {
        Button b = new Button(this);
        b.setText(title);
        b.setAllCaps(false);
        b.setOnClickListener(v -> action.run());
        parent.addView(b, new LinearLayout.LayoutParams(-1, -2));
    }

    private void info(String event, String detail) {
        String line = event + " " + detail;
        Log.i(TAG, line);
        runOnUiThread(() -> report.append(line + "\n"));
    }
    private void fail(String stage, Exception error) {
        Log.e(TAG, stage, error);
        info("ERROR", stage + " " + error.toString());
    }

    private void checkGate() {
        try {
            int value = gate.peek();
            info("VIVO_GATE_PROBE", "key40_before=" + value + " device=" + Build.MODEL);
        } catch (Exception e) { fail("VIVO_GATE_UNAVAILABLE", e); }
    }

    private void openMode(String id, boolean full200) {
        if (openPending || device != null || session != null) {
            info("OPEN_REFUSED", "Close the current camera first");
            return;
        }
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            info("OPEN_REFUSED", "CAMERA permission not granted");
            return;
        }
        try {
            if (!gate.acquire()) {
                info("OPEN_REFUSED", "Vivo gate unavailable / key40 not confirmed");
                return;
            }
            openPending = true;
            activeCameraId = id;
            active200 = full200;
            activeFullWidth = full200 ? F_FULL_W : H_FULL_W;
            activeFullHeight = full200 ? (id.equals("3") ? F_FULL_H_35 : F_FULL_H_85) : H_FULL_H;
            captureInFlight = false;
            decisionPending = false;
            burstActive = false;
            burstSequenceDone = false;
            clearBurstWaitingImages();
            previewSwitched = false;
            activePreviewHeight = id.equals("3") ? RAW_H_H35 : RAW_H_H85;
            characteristics = cameraManager.getCameraCharacteristics(id);
            info("VIVO_GATE_STATE", "stage=before_open " + gate.state());
            info("CAMERA_IDS", Arrays.toString(cameraManager.getCameraIdList()));
            info("CONFIG_TARGET", String.format(Locale.US,
                    "mode=%s camera=%s preview=%dx%d full=%dx%d RAW_SENSOR black=64 white=1023 (profile values)",
                    full200 ? "F200" : "H50", id, RAW_W, activePreviewHeight,
                    activeFullWidth, activeFullHeight));
            // Buffer usage mirrors the GPU data buffer path used by the Vivo HAL.
            long usage = HardwareBuffer.USAGE_GPU_DATA_BUFFER;
            rawReader = ImageReader.newInstance(RAW_W, activePreviewHeight, ImageFormat.RAW_SENSOR, 3, usage);
            fullReader = ImageReader.newInstance(activeFullWidth, activeFullHeight, ImageFormat.RAW_SENSOR, 2, usage);
            yuvReader = ImageReader.newInstance(YUV_W, YUV_H, ImageFormat.YUV_420_888, 3);
            rawReader.setOnImageAvailableListener(r -> onRawPreview(r), worker);
            fullReader.setOnImageAvailableListener(r -> onFullRaw(r), worker);
            yuvReader.setOnImageAvailableListener(r -> {
                Image image = r.acquireLatestImage();
                if (image != null) image.close();
            }, worker);
            cameraManager.openCamera(id, new CameraDevice.StateCallback() {
                @Override public void onOpened(CameraDevice c) {
                    openPending = false;
                    device = c;
                    info("CAMERA_OPENED", "id=" + id + " key40=" + gate.peekSafe());
                    configureSession(c);
                }
                @Override public void onDisconnected(CameraDevice c) {
                    openPending = false;
                    info("CAMERA_DISCONNECTED", "id=" + id);
                    c.close();
                }
                @Override public void onError(CameraDevice c, int error) {
                    openPending = false;
                    info("CAMERA_ERROR", "id=" + id + " code=" + error);
                    c.close();
                }
                @Override public void onClosed(CameraDevice c) {
                    openPending = false;
                    info("CAMERA_CLOSED", "id=" + id);
                    if (device == c) device = null;
                    cleanupReaders();
                    gate.restore();
                }
            }, worker);
        } catch (Exception e) {
            openPending = false;
            fail("CAMERA_OPEN_FAILED", e);
            closeCamera();
        }
    }

    private CaptureRequest.Builder newBuilder(int template) throws CameraAccessException {
        CaptureRequest.Builder b = device.createCaptureRequest(template);
        // Important: set both session and request scope independently.
        if (active200) {
            intKey(b, "vivo.control.ultra_highresolution", 1);
        } else {
            intKey(b, "vivo.control.ai_highresolution", 1);
            intKey(b, "vivo.control.ultra_highresolution", 0);
        }
        intKey(b, "vivo.control.is_ProRaw_on", 2);
        intKey(b, "vivo.control.echo.mode", 2);
        intKey(b, "vivo.control.scenery.subfunction", 5);
        intKey(b, "vivo.control.session.uiSwitch_state", 2);
        return b;
    }
    private void addRequestKeys(CaptureRequest.Builder b) {
        intKey(b, "vivo.control.is_pro_mode", 1);
        byteKey(b, "vivo.control.camera_scenery_pro", (byte)1);
    }
    private void addStillKeys(CaptureRequest.Builder b) {
        intKey(b, "com.vivo.current_ui_module", 74);
        intKey(b, "vivo.control.onlyDng", 1);
        intKey(b, "vivo.control.isCapture", 0);
        intKey(b, "vivo.control.sensorMode", 0);
        intKey(b, "vivo.control.isUpscale", active200 ? 1 : 0);
        byteKey(b, "vivo.control.isPAPNeeded", (byte)1);
        long marker = SystemClock.elapsedRealtimeNanos();
        longKey(b, "vivo.control.requestId", marker);
        longKey(b, "vivo.control.frameFlag", marker);
        longKey(b, "vivo.control.globalCaptureId", marker + 5);
    }
    private void intKey(CaptureRequest.Builder b, String name, int v) {
        b.set(new CaptureRequest.Key<>(name, Integer.class), v);
    }
    private void byteKey(CaptureRequest.Builder b, String name, byte v) {
        b.set(new CaptureRequest.Key<>(name, Byte.class), v);
    }
    private void longKey(CaptureRequest.Builder b, String name, long v) {
        b.set(new CaptureRequest.Key<>(name, Long.class), v);
    }

    private void configureSession(CameraDevice c) {
        try {
            CaptureRequest.Builder sessionKeys = newBuilder(CameraDevice.TEMPLATE_PREVIEW);
            ArrayList<OutputConfiguration> outputs = new ArrayList<>();
            outputs.add(new OutputConfiguration(rawReader.getSurface()));
            outputs.add(new OutputConfiguration(fullReader.getSurface()));
            outputs.add(new OutputConfiguration(yuvReader.getSurface()));
            SessionConfiguration config = new SessionConfiguration(
                    SessionConfiguration.SESSION_REGULAR, outputs, cameraExecutor,
                    new CameraCaptureSession.StateCallback() {
                        @Override public void onConfigured(CameraCaptureSession s) {
                            session = s;
                            info("FULLRES_SESSION_CONFIGURED", "camera=" + activeCameraId +
                                    " gate=" + gate.peekSafe() + " 3_outputs=RAW+FULLRAW+YUV");
                            info("VIVO_GATE_STATE", "stage=configured " + gate.state());
                            startPreview(true);
                        }
                        @Override public void onConfigureFailed(CameraCaptureSession s) {
                            info("FULLRES_SESSION_FAILED", "camera=" + activeCameraId);
                            info("VIVO_GATE_STATE", "stage=config_failed " + gate.state());
                            closeCamera();
                        }
                    });
            config.setSessionParameters(sessionKeys.build());
            info("FULLRES_SESSION_REQUEST", "3 outputs; gate=" + gate.peekSafe());
            c.createCaptureSession(config);
        } catch (Exception e) {
            fail("SESSION_CONFIG_EXCEPTION", e);
            closeCamera();
        }
    }

    private void startPreview(boolean includeYuv) {
        if (device == null || session == null) return;
        try {
            CaptureRequest.Builder b = newBuilder(CameraDevice.TEMPLATE_PREVIEW);
            addRequestKeys(b);
            b.addTarget(rawReader.getSurface());
            if (includeYuv) b.addTarget(yuvReader.getSurface());
            session.setRepeatingRequest(b.build(), new CameraCaptureSession.CaptureCallback() {
                @Override public void onCaptureCompleted(CameraCaptureSession s,
                        CaptureRequest request, TotalCaptureResult result) {
                    Long exposure = result.get(CaptureResult.SENSOR_EXPOSURE_TIME);
                    if (exposure != null && exposure > 0) previewExposureNs = exposure;
                }
            }, worker);
            info("RAW_PREVIEW_STARTED", "with_yuv=" + includeYuv);
        } catch (Exception e) { fail("RAW_PREVIEW_FAILED", e); }
    }

    private void onRawPreview(ImageReader reader) {
        Image image = null;
        try {
            image = reader.acquireLatestImage();
            if (image == null) return;
            if (!previewSwitched && !captureInFlight) {
                previewSwitched = true;
                info("RAW_PREVIEW_FRAME", image.getWidth() + "x" + image.getHeight());
                startPreview(false); // Keep companion configured, but stop targeting it.
            }
        } catch (Exception e) { fail("RAW_PREVIEW_IMAGE", e); }
        finally { if (image != null) image.close(); }
    }

    private int computeExifOrientation() {
        // DngCreator's unspecified orientation was 9 (TIFF/EP unknown) on V2547A.
        // Set a valid EXIF 1/3/6/8 explicitly, using sensor and device orientation.
        Integer sensorVal = characteristics == null ? null :
                characteristics.get(CameraCharacteristics.SENSOR_ORIENTATION);
        Integer facing = characteristics == null ? null :
                characteristics.get(CameraCharacteristics.LENS_FACING);
        int sensor = sensorVal == null ? 90 : sensorVal;
        int deviceDeg = deviceOrientationDegrees;
        if (deviceDeg < 0) {
            int rotation = getWindowManager().getDefaultDisplay().getRotation();
            switch (rotation) {
                case Surface.ROTATION_90: deviceDeg = 90; break;
                case Surface.ROTATION_180: deviceDeg = 180; break;
                case Surface.ROTATION_270: deviceDeg = 270; break;
                default: deviceDeg = 0;
            }
        }
        int degrees = facing != null && facing == CameraCharacteristics.LENS_FACING_FRONT
                ? (sensor + deviceDeg) % 360
                : (sensor - deviceDeg + 360) % 360;
        int exif;
        switch (degrees) {
            case 90: exif = ExifInterface.ORIENTATION_ROTATE_90; break;
            case 180: exif = ExifInterface.ORIENTATION_ROTATE_180; break;
            case 270: exif = ExifInterface.ORIENTATION_ROTATE_270; break;
            default: exif = ExifInterface.ORIENTATION_NORMAL;
        }
        info("DNG_ORIENTATION", "camera=" + activeCameraId + " device=" + deviceDeg
                + " sensor=" + sensor + " rotation=" + degrees + " exif=" + exif);
        return exif;
    }

    private void captureSelected() { captureSelected(false); }

    private void captureTwo200() {
        if (!active200) {
            info("BURST_REFUSED", "Select F85 or F35 200MP mode first");
            return;
        }
        captureSelected(true);
    }

    private void captureSelected(boolean twoFrameBurst) {
        if (device == null || session == null) {
            info("CAPTURE_REFUSED", "Camera/session not configured");
            return;
        }
        if (captureInFlight) {
            info("CAPTURE_REFUSED", "Capture in progress; wait for DNG_WRITTEN or ERROR");
            return;
        }
        captureInFlight = true;
        final int generation = ++captureGeneration;
        clearBurstWaitingImages();
        burstActive = twoFrameBurst;
        burstSequenceDone = false;
        burstResultsSeen = burstImagesSeen = burstSavesFinished = burstSavesGood = 0;
        burstFailures = burstWriterInflight = 0;
        lastStillResult.set(null);
        captureExifOrientation = computeExifOrientation();
        info(twoFrameBurst ? "BURST_2_START" : "CAPTURE_START",
                "mode=" + (active200 ? "F200" : "H50") + " camera=" + activeCameraId
                + " expected=" + activeFullWidth + "x" + activeFullHeight
                + " frames=" + (twoFrameBurst ? 2 : 1)
                + " approxRAW_MiB=" + (Math.round(activeFullWidth * (double)activeFullHeight * 2 * (twoFrameBurst ? 2 : 1) / (1024 * 1024))));
        worker.postDelayed(() -> {
            if (captureInFlight && generation == captureGeneration) {
                info(burstActive ? "BURST_2_TIMEOUT" : "CAPTURE_TIMEOUT",
                        "Capture timeout; received=" + burstImagesSeen
                        + " results=" + burstResultsSeen + " saved=" + burstSavesGood
                        + "/" + burstSavesFinished + " failed=" + burstFailures);
                captureInFlight = false;
                decisionPending = false;
                burstActive = false;
                clearBurstWaitingImages();
                if (device != null && session != null) startPreview(false);
            }
        }, twoFrameBurst ? 150000 : 90000);
        if (active200) prepare200(generation);
        else submitStill(generation);
    }

    private void prepare200(int generation) {
        try {
            final CameraCaptureSession activeSession = session;
            decisionPending = true;
            CaptureRequest.Builder d = newBuilder(CameraDevice.TEMPLATE_PREVIEW);
            addRequestKeys(d);
            intKey(d, "com.vivo.current_ui_module", 74);
            d.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF);
            Range<Integer> iso = characteristics.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE);
            int minIso = iso == null ? 100 : iso.getLower();
            d.set(CaptureRequest.SENSOR_SENSITIVITY, minIso);
            Range<Long> exp = characteristics.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE);
            long targetExp = previewExposureNs > 0 ? previewExposureNs : 33333333L;
            if (exp != null) targetExp = Math.max(exp.getLower(), Math.min(exp.getUpper(), targetExp));
            d.set(CaptureRequest.SENSOR_EXPOSURE_TIME, targetExp);
            Range<Integer>[] fps = characteristics.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES);
            if (fps != null && fps.length != 0) {
                Range<Integer> widest = fps[0];
                for (Range<Integer> candidate : fps) {
                    if (candidate.getUpper() - candidate.getLower() > widest.getUpper() - widest.getLower())
                        widest = candidate;
                }
                d.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, widest);
            }
            d.addTarget(yuvReader.getSurface()); // Decision targets ONLY the configured YUV companion.
            info("F200_DECISION_START", "camera=" + activeCameraId + " ISO=" + minIso
                    + " exposureNs=" + targetExp + " module=74 YUV_only");
            activeSession.setRepeatingRequest(d.build(), new CameraCaptureSession.CaptureCallback() {
                @Override public void onCaptureCompleted(CameraCaptureSession s,
                        CaptureRequest request, TotalCaptureResult result) {
                    if (decisionPending && generation == captureGeneration)
                        finishDecision(generation, "result frame=" + result.getFrameNumber());
                }
                @Override public void onCaptureFailed(CameraCaptureSession s,
                        CaptureRequest request, android.hardware.camera2.CaptureFailure failure) {
                    if (decisionPending && generation == captureGeneration)
                        info("F200_DECISION_FAILED", "reason=" + failure.getReason());
                }
            }, worker);
            worker.postDelayed(() -> {
                if (decisionPending && generation == captureGeneration && captureInFlight)
                    finishDecision(generation, "timeout 2000ms; try still anyway");
            }, 2000);
        } catch (Exception e) {
            decisionPending = false;
            captureInFlight = false;
            fail("F200_DECISION_EXCEPTION", e);
            if (session != null) startPreview(false);
        }
    }

    private void finishDecision(int generation, String reason) {
        if (!decisionPending || !captureInFlight || generation != captureGeneration) return;
        decisionPending = false;
        info("F200_DECISION_DONE", reason);
        try {
            session.stopRepeating(); // Do not resume normal RAW preview until still sequence ends.
            if (burstActive) submitBurst200(generation);
            else submitStill(generation);
        } catch (Exception e) {
            fail("F200_STOP_PREVIEW_FAILED", e);
            captureInFlight = false;
            if (session != null) startPreview(false);
        }
    }

    // Queue exactly TWO true F200 still frames after one decision YUV frame.
    // This tests Vivo HAL scheduling and per-frame RAW output, NOT HDR+ merging.
    private void submitBurst200(int generation) {
        if (session == null || device == null || !captureInFlight || !burstActive) {
            info("BURST_2_REFUSED", "Camera closed or test cancelled");
            return;
        }
        try {
            ArrayList<CaptureRequest> requests = new ArrayList<>();
            for (int index = 1; index <= 2; index++) {
                CaptureRequest.Builder b = newBuilder(CameraDevice.TEMPLATE_STILL_CAPTURE);
                addRequestKeys(b);
                addStillKeys(b); // fresh, unique int64 IDs for each request
                b.addTarget(rawReader.getSurface());
                b.addTarget(fullReader.getSurface());
                b.setTag("P29_BURST_FRAME_" + index);
                requests.add(b.build());
            }
            session.captureBurst(requests, new CameraCaptureSession.CaptureCallback() {
                @Override public void onCaptureStarted(CameraCaptureSession sc,
                        CaptureRequest req, long timestamp, long frameNumber) {
                    if (generation == captureGeneration)
                        info("BURST_2_SENSOR_START", "tag=" + req.getTag()
                                + " frame=" + frameNumber + " ts=" + timestamp);
                }
                @Override public void onCaptureCompleted(CameraCaptureSession sc,
                        CaptureRequest request, TotalCaptureResult result) {
                    if (generation != captureGeneration) return;
                    Long timestamp = result.get(CaptureResult.SENSOR_TIMESTAMP);
                    if (timestamp == null || timestamp <= 0) {
                        info("BURST_2_RESULT_INVALID_TS", "tag=" + request.getTag());
                        burstFailures++;
                        return;
                    }
                    int index = "P29_BURST_FRAME_2".equals(request.getTag()) ? 2 : 1;
                    if (burstWaitingResults.containsKey(timestamp)) {
                        info("BURST_2_RESULT_DUPLICATE_TS", "timestamp=" + timestamp);
                        burstFailures++;
                        return;
                    }
                    burstResultsSeen++;
                    burstWaitingResults.put(timestamp, result);
                    burstResultIndices.put(timestamp, index);
                    info("BURST_2_RESULT", "index=" + index + " timestamp=" + timestamp
                            + " frame=" + result.getFrameNumber()
                            + " iso=" + result.get(CaptureResult.SENSOR_SENSITIVITY)
                            + " exposureNs=" + result.get(CaptureResult.SENSOR_EXPOSURE_TIME));
                    pairBurstFrame(timestamp, generation);
                }
                @Override public void onCaptureFailed(CameraCaptureSession sc,
                        CaptureRequest req, android.hardware.camera2.CaptureFailure failure) {
                    if (generation == captureGeneration) {
                        burstFailures++;
                        info("BURST_2_CAPTURE_FAILED", "tag=" + req.getTag()
                                + " reason=" + failure.getReason());
                    }
                }
                @Override public void onCaptureSequenceCompleted(CameraCaptureSession sc,
                        int sequenceId, long frameNumber) {
                    if (generation != captureGeneration) return;
                    burstSequenceDone = true;
                    info("BURST_2_SEQUENCE_DONE", "sequence=" + sequenceId
                            + " lastFrame=" + frameNumber);
                    finishBurstIfReady(generation);
                }
                @Override public void onCaptureSequenceAborted(CameraCaptureSession sc, int sequenceId) {
                    if (generation != captureGeneration) return;
                    burstFailures++;
                    burstSequenceDone = true;
                    info("BURST_2_SEQUENCE_ABORTED", "sequence=" + sequenceId);
                    finishBurstIfReady(generation);
                }
            }, worker);
            info("BURST_2_SUBMITTED", "camera=" + activeCameraId
                    + " frames=2 full=" + activeFullWidth + "x" + activeFullHeight
                    + " previewStopped=true 10bit black64 white1023");
        } catch (Exception e) {
            fail("BURST_2_SUBMIT_FAILED", e);
            captureInFlight = false;
            burstActive = false;
            clearBurstWaitingImages();
            if (session != null) startPreview(false);
        }
    }

    private void processBurstRaw(Image image) {
        final long timestamp = image.getTimestamp();
        burstImagesSeen++;
        info("BURST_2_RAW_IMAGE", "count=" + burstImagesSeen
                + " ts=" + timestamp + " raw=" + image.getWidth() + "x" + image.getHeight());
        if (image.getWidth() != activeFullWidth || image.getHeight() != activeFullHeight
                || timestamp <= 0 || burstWaitingImages.containsKey(timestamp)) {
            info("BURST_2_RAW_REJECTED", "size/timestamp invalid or duplicate");
            burstFailures++;
            image.close();
            return;
        }
        burstWaitingImages.put(timestamp, image);
        pairBurstFrame(timestamp, captureGeneration);
    }

    private void pairBurstFrame(long timestamp, int generation) {
        Image image = burstWaitingImages.get(timestamp);
        TotalCaptureResult result = burstWaitingResults.get(timestamp);
        if (image == null || result == null) return;
        Integer index = burstResultIndices.get(timestamp);
        burstWaitingImages.remove(timestamp);
        burstWaitingResults.remove(timestamp);
        burstResultIndices.remove(timestamp);
        burstWriterInflight++;
        info("BURST_2_FRAME_MATCHED", "index=" + index + " timestamp=" + timestamp);
        final int frameIndex = index == null ? 0 : index;
        final CameraCharacteristics metadata = characteristics;
        final String cameraId = activeCameraId;
        final int orientation = captureExifOrientation;
        fileWriter.post(() -> {
            boolean saved = false;
            try {
                String file = "XENIUS_" + cameraId + "_F200_B2_F" + frameIndex
                        + "_" + System.currentTimeMillis() + ".dng";
                ContentValues values = new ContentValues();
                values.put(MediaStore.Images.Media.DISPLAY_NAME, file);
                values.put(MediaStore.Images.Media.MIME_TYPE, "image/x-adobe-dng");
                values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_DCIM + "/XeniusFullRes");
                values.put(MediaStore.Images.Media.IS_PENDING, 1);
                ContentResolver resolver = getContentResolver();
                Uri uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                if (uri == null) throw new IllegalStateException("MediaStore returned null");
                try {
                    try (OutputStream out = resolver.openOutputStream(uri);
                         DngCreator dng = new DngCreator(metadata, result)) {
                        if (out == null) throw new IllegalStateException("OutputStream is null");
                        dng.setOrientation(orientation);
                        dng.writeImage(out, image);
                    }
                    fix200BlackLevel(resolver, uri); // Same 64/1023 P27 TIFF metadata correction
                    ContentValues done = new ContentValues();
                    done.put(MediaStore.Images.Media.IS_PENDING, 0);
                    resolver.update(uri, done, null, null);
                    saved = true;
                    info("BURST_2_DNG_WRITTEN", "index=" + frameIndex
                            + " ts=" + timestamp + " file=" + file);
                } catch (Exception error) {
                    resolver.delete(uri, null, null);
                    throw error;
                }
            } catch (Exception error) {
                fail("BURST_2_DNG_ERROR frame=" + frameIndex, error);
            } finally {
                image.close();
                final boolean didSave = saved;
                worker.post(() -> {
                    burstWriterInflight--;
                    burstSavesFinished++;
                    if (didSave) burstSavesGood++;
                    drainBurstReader();
                    finishBurstIfReady(generation);
                });
            }
        });
    }

    private void drainBurstReader() {
        if (!burstActive || fullReader == null) return;
        try {
            // Defensive retry: HAL may have queued a frame without a new callback.
            for (int n = 0; n < 2; n++) {
                Image pending = fullReader.acquireNextImage();
                if (pending == null) break;
                processBurstRaw(pending);
            }
        } catch (IllegalStateException e) {
            info("BURST_2_READER_BUSY", e.getMessage());
        } catch (Exception e) { fail("BURST_2_DRAIN_ERROR", e); }
    }

    private void finishBurstIfReady(int generation) {
        if (generation != captureGeneration || !burstActive) return;
        if (burstSavesFinished < 2 || !burstSequenceDone) return;
        info("BURST_2_FINAL", "resultCount=" + burstResultsSeen
                + " rawCount=" + burstImagesSeen + " saved=" + burstSavesGood
                + "/2 failures=" + burstFailures
                + " timestampsMatched=" + (burstSavesFinished == 2));
        captureInFlight = false;
        burstActive = false;
        clearBurstWaitingImages();
        if (session != null && device != null) startPreview(false);
    }

    private void clearBurstWaitingImages() {
        for (Image image : burstWaitingImages.values()) {
            try { image.close(); } catch (Exception ignored) { }
        }
        burstWaitingImages.clear();
        burstWaitingResults.clear();
        burstResultIndices.clear();
    }

    private void submitStill(int generation) {
        if (session == null || device == null) {
            info("CAPTURE_REFUSED", "Camera disconnected before still submission");
            captureInFlight = false;
            return;
        }
        try {
            CaptureRequest.Builder b = newBuilder(CameraDevice.TEMPLATE_STILL_CAPTURE);
            addRequestKeys(b);
            addStillKeys(b);
            b.addTarget(rawReader.getSurface());
            b.addTarget(fullReader.getSurface());
            session.capture(b.build(), new CameraCaptureSession.CaptureCallback() {
                @Override public void onCaptureCompleted(CameraCaptureSession s,
                         CaptureRequest request, TotalCaptureResult result) {
                    lastStillResult.set(result);
                    info("CAPTURE_RESULT", "frame=" + result.getFrameNumber()
                            + " sensorTimestamp=" + result.get(CaptureResult.SENSOR_TIMESTAMP));
                }
                @Override public void onCaptureFailed(CameraCaptureSession s,
                         CaptureRequest request, android.hardware.camera2.CaptureFailure failure) {
                    info("CAPTURE_FAILED", "reason=" + failure.getReason());
                    captureInFlight = false;
                }
                @Override public void onCaptureSequenceCompleted(CameraCaptureSession s,
                        int sequenceId, long frameNumber) {
                    info("STILL_SEQUENCE_COMPLETE", "sequence=" + sequenceId + " frame=" + frameNumber);
                    if (active200 && device != null && session != null) startPreview(false);
                }
                @Override public void onCaptureSequenceAborted(CameraCaptureSession s, int sequenceId) {
                    info("STILL_SEQUENCE_ABORTED", "sequence=" + sequenceId);
                    captureInFlight = false;
                    if (active200 && device != null && session != null) startPreview(false);
                }
            }, worker);
            info(active200 ? "CAPTURE_200_SUBMITTED" : "CAPTURE_50_SUBMITTED",
                    "RAW full=" + activeFullWidth + "x" + activeFullHeight + " camera=" + activeCameraId);
        } catch (Exception e) {
            captureInFlight = false;
            fail("CAPTURE_SUBMIT_FAILED", e);
            if (active200 && session != null) startPreview(false);
        }
    }

    private void onFullRaw(ImageReader reader) {
        Image image = null;
        try {
            image = reader.acquireNextImage();
            if (image == null) return;
            final Image held = image;
            image = null;
            if (burstActive) {
                processBurstRaw(held);
                return;
            }
            ++capturedImages;
            info("FULLRES_RAW_RECEIVED", "count=" + capturedImages +
                    " width=" + held.getWidth() + " height=" + held.getHeight() +
                    " format=" + held.getFormat() + " ts=" + held.getTimestamp());
            try {
                HardwareBuffer hb = held.getHardwareBuffer();
                if (hb != null) {
                    info("FULLRES_HWBUFFER", "w=" + hb.getWidth() + " h=" + hb.getHeight() +
                            " fmt=" + hb.getFormat() + " layers=" + hb.getLayers() +
                            " usage=" + hb.getUsage());
                    hb.close();
                } else { info("FULLRES_HWBUFFER", "null"); }
            } catch (Exception e) { info("FULLRES_HWBUFFER_ERROR", e.toString()); }
            // Capture result may arrive after the ImageReader callback.
            worker.postDelayed(() -> saveOrInspect(held, 0), 400);
        } catch (Exception e) { fail("FULLRES_IMAGE_ERROR", e); }
        finally { if (image != null) image.close(); }
    }

    // DngCreator sometimes uses CaptureResult.BLACK_LEVEL_PATTERN=0 for 200 MP even
    // though the V2547A F200 stream contains 10-bit values with black about 64.
    // Patch TIFF/DNG BlackLevel metadata only; do NOT change Bayer pixel data.
    // Do not alter the RGGB CFA tag: test previews of both F200 frames were natural
    // with RGGB, whereas trying GRBG on the F35 200MP sample made it pink.
    private static byte[] readDngBytes(FileDescriptor fd, int length, long offset) throws Exception {
        byte[] data = new byte[length];
        int done = 0;
        while (done < length) {
            int n = Os.pread(fd, data, done, length - done, offset + done);
            if (n <= 0) throw new IllegalStateException("TIFF short read at " + (offset + done));
            done += n;
        }
        return data;
    }
    private static void writeDngBytes(FileDescriptor fd, byte[] data, long offset) throws Exception {
        int done = 0;
        while (done < data.length) {
            int n = Os.pwrite(fd, data, done, data.length - done, offset + done);
            if (n <= 0) throw new IllegalStateException("TIFF short write at " + (offset + done));
            done += n;
        }
    }
    private void fix200BlackLevel(ContentResolver cr, Uri uri) throws Exception {
        try (ParcelFileDescriptor pfd = cr.openFileDescriptor(uri, "rw")) {
            if (pfd == null) throw new IllegalStateException("Could not reopen DNG for metadata fix");
            FileDescriptor fd = pfd.getFileDescriptor();
            byte[] header = readDngBytes(fd, 8, 0);
            boolean littleEndian = header[0] == 'I' && header[1] == 'I';
            if (!littleEndian && !(header[0] == 'M' && header[1] == 'M'))
                throw new IllegalArgumentException("Not a TIFF header");
            ByteOrder order = littleEndian ? ByteOrder.LITTLE_ENDIAN : ByteOrder.BIG_ENDIAN;
            ByteBuffer h = ByteBuffer.wrap(header).order(order);
            if (Short.toUnsignedInt(h.getShort(2)) != 42)
                throw new IllegalArgumentException("Only classic TIFF DNG supported");
            long ifd = Integer.toUnsignedLong(h.getInt(4));
            if (ifd < 8 || ifd > 64L * 1024 * 1024)
                throw new IllegalArgumentException("Invalid TIFF IFD offset=" + ifd);
            ByteBuffer nTag = ByteBuffer.wrap(readDngBytes(fd, 2, ifd)).order(order);
            int count = Short.toUnsignedInt(nTag.getShort());
            if (count < 1 || count > 4096)
                throw new IllegalArgumentException("Invalid TIFF tag count=" + count);
            for (int i = 0; i < count; i++) {
                byte[] entry = readDngBytes(fd, 12, ifd + 2L + i * 12L);
                ByteBuffer t = ByteBuffer.wrap(entry).order(order);
                int tag = Short.toUnsignedInt(t.getShort(0));
                if (tag != 50714) continue; // DNG BlackLevel
                int type = Short.toUnsignedInt(t.getShort(2));
                long elements = Integer.toUnsignedLong(t.getInt(4));
                long offset = Integer.toUnsignedLong(t.getInt(8));
                if (type != 5 || elements != 4)
                    throw new IllegalArgumentException("Unexpected DNG BlackLevel type=" + type + " count=" + elements);
                byte[] values = readDngBytes(fd, 32, offset);
                ByteBuffer b = ByteBuffer.wrap(values).order(order);
                int[] numerator = new int[4];
                long[] denominator = new long[4];
                for (int k = 0; k < 4; k++) {
                    numerator[k] = b.getInt(k * 8);
                    denominator[k] = Integer.toUnsignedLong(b.getInt(k * 8 + 4));
                    if (denominator[k] == 0 || denominator[k] > 1000000)
                        throw new IllegalArgumentException("Invalid BlackLevel denominator=" + denominator[k]);
                }
                boolean zero = true;
                for (int k = 0; k < 4; k++) if (numerator[k] != 0) zero = false;
                if (!zero) {
                    info("F200_BLACKLEVEL_ALREADY_SET", "value=" + numerator[0] + "/" + denominator[0]);
                    return;
                }
                for (int k = 0; k < 4; k++)
                    b.putInt(k * 8, Math.toIntExact(64L * denominator[k]));
                writeDngBytes(fd, values, offset);
                byte[] verify = readDngBytes(fd, 32, offset);
                if (!Arrays.equals(values, verify))
                    throw new IllegalStateException("BlackLevel metadata write verification failed");
                info("F200_DNG_BLACKLEVEL_FIXED", "0 -> 64/1023; CFA=RGGB preserved; RAW pixels unchanged");
                return;
            }
            throw new IllegalStateException("DNG BlackLevel tag not found");
        }
    }

    private void saveOrInspect(Image image, int metadataAttempts) {
        // Unlike 50 MP, full 200 MP RAW metadata can arrive well after the large Image.
        // Keep the Image open until its capture result arrives, within a bounded wait.
        if (lastStillResult.get() == null && metadataAttempts < 60 && session != null) {
            worker.postDelayed(() -> saveOrInspect(image, metadataAttempts + 1), 200);
            return;
        }
        try {
            try {
                Image.Plane[] planes = image.getPlanes();
                if (planes.length > 0) {
                    info("RAW_PLANE", "rowStride=" + planes[0].getRowStride() +
                            " pixelStride=" + planes[0].getPixelStride() +
                            " remaining=" + planes[0].getBuffer().remaining());
                }
            } catch (Exception e) {
                info("RAW_PLANE_UNAVAILABLE", "GPU_DATA_BUFFER path: " + e.getClass().getSimpleName());
            }
            TotalCaptureResult result = lastStillResult.get();
            if (result == null || characteristics == null) {
                info("DNG_NOT_READY", "Capture result absent after wait (attempts="
                        + metadataAttempts + "); RAW image released");
                return;
            }
            ContentValues values = new ContentValues();
            String file = "XENIUS_" + activeCameraId + (active200 ? "_F200_" : "_H50_")
                    + System.currentTimeMillis() + ".dng";
            values.put(MediaStore.Images.Media.DISPLAY_NAME, file);
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/x-adobe-dng");
            values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_DCIM + "/XeniusFullRes");
            values.put(MediaStore.Images.Media.IS_PENDING, 1);
            ContentResolver cr = getContentResolver();
            Uri uri = cr.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new IllegalStateException("MediaStore.insert returned null");
            try {
                try (OutputStream out = cr.openOutputStream(uri); DngCreator dng = new DngCreator(characteristics, result)) {
                    if (out == null) throw new IllegalStateException("MediaStore OutputStream null");
                    dng.setOrientation(captureExifOrientation);
                    dng.writeImage(out, image);
                }
                if (active200) {
                    try { fix200BlackLevel(cr, uri); }
                    catch (Exception metadataError) {
                        // Keep the RAW rather than deleting an otherwise successful capture.
                        info("F200_BLACKLEVEL_FIX_FAILED", metadataError.toString());
                        Log.e(TAG, "F200 DNG metadata fix failed", metadataError);
                    }
                }
                ContentValues finish = new ContentValues();
                finish.put(MediaStore.Images.Media.IS_PENDING, 0);
                cr.update(uri, finish, null, null);
                info("DNG_WRITTEN", "file=" + file + " orientation=" + captureExifOrientation
                        + " mode=" + (active200 ? "F200" : "H50")
                        + " raw=" + image.getWidth() + "x" + image.getHeight());
            } catch (Exception e) {
                cr.delete(uri, null, null);
                throw e;
            }
        } catch (Exception e) {
            fail("DNG_WRITE_UNSUPPORTED", e);
            info("NEXT_DIAGNOSTIC", "HardwareBuffer NDK lock/copy needed if GPU-only RAW plane blocked");
        } finally {
            image.close();
            captureInFlight = false;
        }
    }

    private void cleanupReaders() {
        session = null;
        previewSwitched = false;
        lastStillResult.set(null);
        captureInFlight = false;
        decisionPending = false;
        burstActive = false;
        clearBurstWaitingImages();
        ++captureGeneration;
        if (rawReader != null) { rawReader.close(); rawReader = null; }
        if (fullReader != null) { fullReader.close(); fullReader = null; }
        if (yuvReader != null) { yuvReader.close(); yuvReader = null; }
    }
    private void closeCamera() {
        info("CLOSE_REQUESTED", "camera=" + activeCameraId + " pending=" + openPending);
        if (session != null) { session.close(); session = null; }
        if (device != null) { device.close(); /* gate restored in onClosed */ }
        else if (!openPending) { cleanupReaders(); gate.restore(); }
        else { info("CLOSE_DEFERRED", "waiting for camera open/onError callback"); }
    }
    @Override protected void onDestroy() {
        if (orientationListener != null) orientationListener.disable();
        worker.post(this::closeCamera);
        writerThread.quitSafely();
        super.onDestroy();
    }

    private final class VivoGate {
        private Object instance;
        private Method getInfo, setValue;
        private Integer previous;
        private boolean owned;
        private final String PENDING = "gate_owned";
        private final String BEFORE = "gate_previous";
        private void init() throws Exception {
            if (instance != null) return;
            Class<?> cls = Class.forName("android.hardware.vivocamera.VivoCameraManager");
            instance = cls.getMethod("getInstance").invoke(null);
            getInfo = cls.getMethod("getInfo", int.class);
            setValue = cls.getMethod("setValue", int.class, int.class);
        }
        int peek() throws Exception {
            init();
            Object value = getInfo.invoke(instance, 40);
            return ((Number)value).intValue();
        }
        String peekSafe() {
            try { return Integer.toString(peek()); }
            catch (Exception e) { return "unreadable"; }
        }
        String state() {
            return "key1=" + peekIdSafe(1) + " key33=" + peekIdSafe(33) + " key40=" + peekIdSafe(40);
        }
        String peekIdSafe(int id) {
            try { init(); return Integer.toString(((Number)getInfo.invoke(instance, id)).intValue()); }
            catch (Exception e) { return "?"; }
        }
        void recoverIfLeftActive() {
            if (!getPreferences(Context.MODE_PRIVATE).getBoolean(PENDING, false)) return;
            int prev = getPreferences(Context.MODE_PRIVATE).getInt(BEFORE, -1);
            try {
                if (prev >= 0 && peek() == 1) {
                    setValue.invoke(instance, 40, prev);
                    info("VIVO_GATE_RECOVERED", "restored=" + prev);
                }
                getPreferences(Context.MODE_PRIVATE).edit().putBoolean(PENDING, false).apply();
            } catch (Exception e) { fail("VIVO_GATE_RECOVERY_FAILED", e); }
        }
        boolean acquire() {
            try {
                previous = peek();
                if (previous < 0) throw new IllegalStateException("Cannot read previous key40");
                getPreferences(Context.MODE_PRIVATE).edit()
                        .putInt(BEFORE, previous).putBoolean(PENDING, true).commit();
                setValue.invoke(instance, 40, 1);
                // The vendor provider update is asynchronous on some firmware.
                SystemClock.sleep(200);
                if (peek() != 1) throw new IllegalStateException("key40 did not become 1");
                owned = true;
                info("VIVO_GATE_ACQUIRED", "before=" + previous + " now=" + peek());
                info("VIVO_GATE_STATE", "stage=acquired " + state());
                return true;
            } catch (Exception e) {
                fail("VIVO_GATE_ACQUIRE_FAILED", e);
                restore();
                return false;
            }
        }
        void restore() {
            if (previous == null) return;
            try {
                init();
                setValue.invoke(instance, 40, previous);
                SystemClock.sleep(100);
                info("VIVO_GATE_RESTORED", "expected=" + previous + " actual=" + peekSafe());
                info("VIVO_GATE_STATE", "stage=restored " + state());
                getPreferences(Context.MODE_PRIVATE).edit().putBoolean(PENDING, false).commit();
                owned = false;
                previous = null;
            } catch (Exception e) { fail("VIVO_GATE_RESTORE_FAILED", e); }
        }
    }
}
