# Xenius FullRes P27 - F200 DNG BlackLevel metadata correction

P26 full-resolution 50/200 MP capture path preserved. When 200 MP capture returns a DNG with BlackLevel 0 instead of ~64, P27 rewrites only DNG TIFF tag 50714 to 64. The correction uses MediaStore URI through an Android file descriptor and preserves all RAW Bayer pixels and RGGB CFA metadata.

This is an experimental correction for Vivo X300 Ultra V2547A. P26 user RAW shows 10-bit RAW values and incorrect BlackLevel=0 in F200 DNG. The first 50MP H35/H85 RAW files have BlackLevel ~64. Color rendering must still be verified on device.

The TIFF parser supports classic II/MM TIFF DNG, RATIONAL count 4; it verifies the write; other data is unchanged.
# Xenius FullRes P25B — Orientation Fix

Built from functioning P25A 50MP H35/H85 capture prototype. Original P25A stored 9 (unknown) in TIFF Orientation tag. P25B explicitly writes DNG Orientation 1/3/6/8 based on device orientation and sensor orientation when shutter is pressed. No changes to RAW data, Vivo gate, RAW stream, camera IDs, or vendor keys. Install test build after uninstalling P25A if debug signing differs.

# Xenius FullRes P25A — independent Camera2 H85/H35 50 MP probe

**Status:** original, buildable Android Studio / Gradle *source*, not a tested or compiled APK.

The original Xenius/GCam P24 APK is **not modified**. This experiment has package
`com.xenius.fullresprobe` and can coexist with the existing application. The
same package could not be updated offline without P24's private signing key.

## Goal

1. Acquire Vivo's hidden `VivoCameraManager` key 40 safely, before opening camera.
2. Create a 3-output session: 4080×3072 RAW_SENSOR for H85 / 4080×3064 for H35 (preview), 8192×6144
   RAW_SENSOR (still), 640×480 YUV_420_888 (companion).
3. Apply the H85/H35 session + request vendor tags.
4. Capture one 50 MP RAW image; if the OS allows, try saving an Android
   `DngCreator` file to `DCIM/XeniusFullRes`. Otherwise log the precise
   obstacle (`GPU_DATA_BUFFER` may require NDK/AHardwareBuffer CPU lock).
5. Restore the global Vivo key when camera is closed.

## Build

- Android Studio (JDK 17, Android SDK platform 35) → open this directory →
  **Build APK(s)** → `app/build/outputs/apk/debug/app-debug.apk`.
- Or create a GitHub repository with these files and use **Actions → Xenius
  FullRes P25 APK → Run workflow**. The `XeniusFullResP25A-debug-apk` artifact
  contains the APK. The workflow has **not been executed** here.

## Test

Install separately; grant camera permission. Close the ordinary Xenius P24
before testing (both apps cannot own Camera ID 5 simultaneously). In P25,
press **Check Vivo key40**, **Open H85**, wait for `FULLRES_SESSION_CONFIGURED`,
then **Capture H85 / 50 MP**; finally **Close camera** to restore the gate.

LADB capture:

```sh
logcat -c
logcat -s XENIUS_P25A:I CameraService:E Camera3-Device:E *:S -v time > /sdcard/Download/XENIUS_P25A_LOG.txt
```

Note: some shells do not permit streaming shell redirection on `/sdcard` with
plain `>`; use `logcat -d -s XENIUS_P25A:I *:S > /sdcard/Download/XENIUS_P25A_LOG.txt`
after test if necessary.

Expected markers: `VIVO_GATE_ACQUIRED`, `CAMERA_OPENED`,
`FULLRES_SESSION_CONFIGURED`, `RAW_PREVIEW_FRAME`, `CAPTURE_50_SUBMITTED`,
`FULLRES_RAW_RECEIVED`, `DNG_WRITTEN` or `DNG_WRITE_UNSUPPORTED`,
`VIVO_GATE_RESTORED`.

**Safety:** this changes a system-wide Vivo key temporarily. Do not run
concurrently with the stock camera; close before switching apps. If gate
restoration fails after an unexpected crash, the app tries recovery at next
launch. A device reboot can be used to reset vendor state if needed.

## Limitations

- A usable 50 MP DNG is **not established**. `DngCreator` may fail on GPU-only
  RAW buffers. NDK hardware-buffer copying is the P26 step, once we get the
  exact H85 response on the target Vivo V2547A.
- 8192×6144 is the HAL buffer size; active Bayer region can be smaller.
- Pixel data and DNG color levels must be validated: RawR's X300 Ultra profile
  indicates black=64 / white=1023 in 10-bit values stored in RAW16.
- No 200 MP capture and no GCam HDR+ integration in this P25 source.
- Some Vivo firmware versions may block hidden API reflection or vendor tags;
  the app is designed to report a failure instead of claiming success.

## Technical basis

Developed independently using protocol descriptions from RawR's
`docs/vivo-fullres.md` and `vivo_x300_ultra.json` device profile in the
user-provided RawR source archive. No RawR source has been copied into this
project. Original implementation here, for research and testing.


## P25A extra instrumentation (15 Nov 2026)

- The app logs `VIVO_GATE_STATE stage=acquired`, `before_open`, and `configured`,
  each displaying key1 (AppType), key33 (VCFAppType), and key40. Compare whether
  camera service rewrote AppType to 1 after opening. This read-only state is
  important to distinguish a missing gate from a failed stream combination.
- `FULLRES_HWBUFFER` reports the actual AHardwareBuffer width, height, format,
  usage and layers on the received full-resolution image. This **does not**
  establish CPU readback or correct Bayer color reconstruction.
- `openPending` prevents a second open request while the first is unresolved
  and defers gate restoration if a user closes before the onOpened callback.
- `XENIUS_P25A` is the new `logcat` tag.

## GitHub Actions: APK without local Android SDK

1. Create a new *private* GitHub repository. Upload the **contents** of this
   directory preserving `.github/workflows/build-debug-apk.yml`.
2. Open **Actions → Xenius FullRes P25A APK → Run workflow**. It should install
   Android SDK/build tools and Gradle, then compile and debug-sign the APK.
3. Retrieve `XeniusFullResP25A-debug-apk` from that workflow's artifacts.
   Install it as a separate app, not on top of the working GCam.

No APK was compiled or run in the environment where these sources were packaged.
A successful GitHub build does not prove the Vivo gate, session, or RAW capture
works on V2547A; we must inspect the actual device log.
