# Xenius Stream Lab P31 — standalone full-res RAW probe (vivo X300 Ultra)

Built on the P27 source (P26 50/200 MP capture path + F200 BlackLevel fix). Separate package
`com.xenius.streamlab`, installs next to GCam / P27.

New in P31
- **Dump all cameras + keys**: IDs 0-15 (hidden ones included): stream maps (normal + MAX_RES), binning
  factor, every characteristic incl. vendor tags (com.vivo.*, org.quic.*), request/session/result key
  lists -> `Download/XeniusLab/XLAB_camdump_*.txt`.
- **Variant** (session + every request of one camera open):
  V0 base · V1-V4 `vivo.control.EngineerRemosaicMode` = 0..3 · V5
  `org.codeaurora.qcamera3.sessionParameters.EnableXCFAOptimization` = 1 · V6 NOISE_REDUCTION + EDGE off.
  Vendor keys are tried as int32, then byte; acceptance is logged (VARIANT_APPLIED).
- **Block test** on every captured frame (1024x1024 centre crop): BAYER / QUAD 2x2 / 4x4, with
  neighbour-difference ratios and 4x4 phase means (BLOCK_TEST line). Logs echoed result keys
  (RESULT_ECHO).
- DNG names carry the variant: `XLAB_<id>_<H50|F200>_<variant>_<ts>.dng` in DCIM/XeniusFullRes.
- **Save this log** -> `Download/XeniusLab/XLAB_log_*.txt`.

## P32
- Variants: V0 base · V1 `vivo.control.seamless.remosaic.enable`=1 · V2-V5 `EngineerRemosaicMode` 4/5/6/8 ·
  V6 NR+edge off · V7 `vivo.control.forceSensorMode`=N (N chosen with the "V7 value" button, 0-40).
- **Auto sweep forceSensorMode 0-40** on ID 5: plain session, largest RAW stream only, no key40; one frame
  per mode with size, block test, light level and result echo (SWEEP_MODE lines). Close = stop.
- Remosaic calibration blobs (`vivo.feedback.remosaicEepromData`, `remosaicSensorOtpData`) saved once per run
  to `Download/XeniusLab/*.bin`. Result echo shows big arrays as length only.
- Block test reports mean level and flags TOO DARK scenes.

## P33
- Sweep survives HAL crashes: after CAMERA_ERROR 4 it waits (up to 45 s) for the camera service to come back,
  then continues; "unknown device" opens are retried (3x) instead of skipped. Crashing modes are listed at the end.
- Sweep starts at the V7 value (so a sweep can be resumed from any mode).
- P32 sweep result on ID 5: modes 19-22 DCG Bayer (black ~1024), 23 Bayer (black 64); 1 and 24 crash the HAL;
  0 gives no frames.

## P34
- "50 MP stream" switch: 8192x6144 (hardware-remosaic size) or native 8160x6144 (8160x6128 on ID 3), for
  testing non-remosaic sensor modes (forceSensorMode 1 / 27 on ID 5, 1 / 3 on ID 3) at their native size.
  DNGs from the native size are named XLAB_<id>_H50N_...

## P35
- **Auto sweep 50 MP** (ID 5 + ID 3, or one of them): for each `forceSensorMode` (V7 value .. 40) it opens the real
  50 MP path (key40 + full-res session, RAW + full RAW + YUV), captures one 50 MP still, and logs one
  `SWEEP50_MODE` line: where the real pixels sit in the buffer (unwritten = 0: data %, bounding box, mean level)
  and the block test (BAYER / QUAD 2x2 / 4x4) centred on that data, plus the result echo. No DNGs are saved.
  Silent modes (no preview / no still in 20 s) and HAL crashes are recorded; after a crash it waits for the camera
  service and continues. A summary is printed at the end. Uses the "50 MP stream" size (8192 or native 8160).
- "Close camera" stops the sweep.
