package com.xenius.fullresprobe;

import android.Manifest;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.ImageFormat;
import android.hardware.HardwareBuffer;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.CaptureResult;
import android.hardware.camera2.DngCreator;
import android.hardware.camera2.TotalCaptureResult;
import android.hardware.camera2.params.OutputConfiguration;
import android.hardware.camera2.params.SessionConfiguration;
import android.media.Image;
import android.media.ImageReader;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.OutputStream;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Independent Camera2 experiment informed by publicly documented Vivo protocol.
 * Does not modify an existing GCam package and does not reuse RawR source code.
 * Capture is experimental: HAL may reject stream sizes, keys or DNG metadata.
 */
public final class MainActivity extends Activity {
    private static final String TAG = "XENIUS_P25A";
    private static final int PERMISSION_REQUEST = 25;
    private static final int RAW_W = 4080, RAW_H_H85 = 3072, RAW_H_H35 = 3064;
    private static final int FULL_W = 8192, FULL_H = 6144;
    private static final int YUV_W = 640, YUV_H = 480;
    private HandlerThread workerThread;
    private Handler worker;
    private Executor cameraExecutor;
    private TextView report;
    private CameraManager cameraManager;
    private CameraDevice device;
    private CameraCaptureSession session;
    private ImageReader rawReader, fullReader, yuvReader;
    private CameraCharacteristics characteristics;
    private String activeCameraId;
    private int activePreviewHeight = RAW_H_H85;
    private int capturedImages = 0;
    private boolean openPending = false;
    private boolean previewSwitched = false;
    private final AtomicReference<TotalCaptureResult> lastStillResult = new AtomicReference<>();
    private final VivoGate gate = new VivoGate();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        workerThread = new HandlerThread("xenius-p25-camera");
        workerThread.start();
        worker = new Handler(workerThread.getLooper());
        cameraExecutor = r -> worker.post(r);
        cameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(18, 16, 18, 16);
        addButton(root, "1. Check Vivo key40", () -> worker.post(this::checkGate));
        addButton(root, "2. Open H85 / Camera ID 5", () -> worker.post(() -> openH("5")));
        addButton(root, "3. Capture H85 / 50 MP", () -> worker.post(this::capture50));
        addButton(root, "4. Close camera and restore key40", () -> worker.post(this::closeCamera));
        addButton(root, "Alternative: Open H35 / Camera ID 3", () -> worker.post(() -> openH("3")));
        report = new TextView(this);
        report.setTextSize(12);
        report.setTextIsSelectable(true);
        report.setText("P25A: H85/H35 50 MP RAW protocol probe. Existing GCam unchanged.\n");
        ScrollView scroll = new ScrollView(this);
        scroll.addView(report);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
        worker.post(gate::recoverIfLeftActive);
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, PERMISSION_REQUEST);
        }
    }

    private void addButton(LinearLayout parent, String title, Runnable action) {
        Button b = new Button(this);
        b.setText(title);
        b.setAllCaps(false);
        b.setOnClickListener(v -> action.run());
        parent.addView(b, new LinearLayout.LayoutParams(-1, -2));
    }

    private void info(String event, String detail) {
        String line = event + " " + detail;
        Log.i(TAG, line);
        runOnUiThread(() -> report.append(line + "\n"));
    }
    private void fail(String stage, Exception error) {
        Log.e(TAG, stage, error);
        info("ERROR", stage + " " + error.toString());
    }

    private void checkGate() {
        try {
            int value = gate.peek();
            info("VIVO_GATE_PROBE", "key40_before=" + value + " device=" + Build.MODEL);
        } catch (Exception e) { fail("VIVO_GATE_UNAVAILABLE", e); }
    }

    private void openH(String id) {
        if (openPending || device != null || session != null) {
            info("OPEN_REFUSED", "Close the current camera first");
            return;
        }
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            info("OPEN_REFUSED", "CAMERA permission not granted");
            return;
        }
        try {
            if (!gate.acquire()) {
                info("OPEN_REFUSED", "Vivo gate unavailable / key40 not confirmed");
                return;
            }
            openPending = true;
            activeCameraId = id;
            activePreviewHeight = id.equals("3") ? RAW_H_H35 : RAW_H_H85;
            characteristics = cameraManager.getCameraCharacteristics(id);
            info("VIVO_GATE_STATE", "stage=before_open " + gate.state());
            info("CAMERA_IDS", Arrays.toString(cameraManager.getCameraIdList()));
            info("CONFIG_TARGET", String.format(Locale.US,
                    "camera=%s preview=%dx%d full=%dx%d RAW_SENSOR black=64 white=1023 (profile values)",
                    id, RAW_W, activePreviewHeight, FULL_W, FULL_H));
            // Buffer usage mirrors the GPU data buffer path used by the Vivo HAL.
            long usage = HardwareBuffer.USAGE_GPU_DATA_BUFFER;
            rawReader = ImageReader.newInstance(RAW_W, activePreviewHeight, ImageFormat.RAW_SENSOR, 3, usage);
            fullReader = ImageReader.newInstance(FULL_W, FULL_H, ImageFormat.RAW_SENSOR, 2, usage);
            yuvReader = ImageReader.newInstance(YUV_W, YUV_H, ImageFormat.YUV_420_888, 3);
            rawReader.setOnImageAvailableListener(r -> onRawPreview(r), worker);
            fullReader.setOnImageAvailableListener(r -> onFullRaw(r), worker);
            yuvReader.setOnImageAvailableListener(r -> {
                Image image = r.acquireLatestImage();
                if (image != null) image.close();
            }, worker);
            cameraManager.openCamera(id, new CameraDevice.StateCallback() {
                @Override public void onOpened(CameraDevice c) {
                    openPending = false;
                    device = c;
                    info("CAMERA_OPENED", "id=" + id + " key40=" + gate.peekSafe());
                    configureSession(c);
                }
                @Override public void onDisconnected(CameraDevice c) {
                    openPending = false;
                    info("CAMERA_DISCONNECTED", "id=" + id);
                    c.close();
                }
                @Override public void onError(CameraDevice c, int error) {
                    openPending = false;
                    info("CAMERA_ERROR", "id=" + id + " code=" + error);
                    c.close();
                }
                @Override public void onClosed(CameraDevice c) {
                    openPending = false;
                    info("CAMERA_CLOSED", "id=" + id);
                    if (device == c) device = null;
                    cleanupReaders();
                    gate.restore();
                }
            }, worker);
        } catch (Exception e) {
            openPending = false;
            fail("CAMERA_OPEN_FAILED", e);
            closeCamera();
        }
    }

    private CaptureRequest.Builder newBuilder(int template) throws CameraAccessException {
        CaptureRequest.Builder b = device.createCaptureRequest(template);
        // Important: set both session and request scope independently.
        intKey(b, "vivo.control.ai_highresolution", 1);
        intKey(b, "vivo.control.ultra_highresolution", 0);
        intKey(b, "vivo.control.is_ProRaw_on", 2);
        intKey(b, "vivo.control.echo.mode", 2);
        intKey(b, "vivo.control.scenery.subfunction", 5);
        intKey(b, "vivo.control.session.uiSwitch_state", 2);
        return b;
    }
    private void addRequestKeys(CaptureRequest.Builder b) {
        intKey(b, "vivo.control.is_pro_mode", 1);
        byteKey(b, "vivo.control.camera_scenery_pro", (byte)1);
    }
    private void addStillKeys(CaptureRequest.Builder b) {
        intKey(b, "com.vivo.current_ui_module", 74);
        intKey(b, "vivo.control.onlyDng", 1);
        intKey(b, "vivo.control.isCapture", 0);
        intKey(b, "vivo.control.sensorMode", 0);
        intKey(b, "vivo.control.isUpscale", 0);
        byteKey(b, "vivo.control.isPAPNeeded", (byte)1);
        long marker = SystemClock.elapsedRealtimeNanos();
        longKey(b, "vivo.control.requestId", marker);
        longKey(b, "vivo.control.frameFlag", marker);
        longKey(b, "vivo.control.globalCaptureId", marker + 5);
    }
    private void intKey(CaptureRequest.Builder b, String name, int v) {
        b.set(new CaptureRequest.Key<>(name, Integer.class), v);
    }
    private void byteKey(CaptureRequest.Builder b, String name, byte v) {
        b.set(new CaptureRequest.Key<>(name, Byte.class), v);
    }
    private void longKey(CaptureRequest.Builder b, String name, long v) {
        b.set(new CaptureRequest.Key<>(name, Long.class), v);
    }

    private void configureSession(CameraDevice c) {
        try {
            CaptureRequest.Builder sessionKeys = newBuilder(CameraDevice.TEMPLATE_PREVIEW);
            ArrayList<OutputConfiguration> outputs = new ArrayList<>();
            outputs.add(new OutputConfiguration(rawReader.getSurface()));
            outputs.add(new OutputConfiguration(fullReader.getSurface()));
            outputs.add(new OutputConfiguration(yuvReader.getSurface()));
            SessionConfiguration config = new SessionConfiguration(
                    SessionConfiguration.SESSION_REGULAR, outputs, cameraExecutor,
                    new CameraCaptureSession.StateCallback() {
                        @Override public void onConfigured(CameraCaptureSession s) {
                            session = s;
                            info("FULLRES_SESSION_CONFIGURED", "camera=" + activeCameraId +
                                    " gate=" + gate.peekSafe() + " 3_outputs=RAW+FULLRAW+YUV");
                            info("VIVO_GATE_STATE", "stage=configured " + gate.state());
                            startPreview(true);
                        }
                        @Override public void onConfigureFailed(CameraCaptureSession s) {
                            info("FULLRES_SESSION_FAILED", "camera=" + activeCameraId);
                            info("VIVO_GATE_STATE", "stage=config_failed " + gate.state());
                            closeCamera();
                        }
                    });
            config.setSessionParameters(sessionKeys.build());
            info("FULLRES_SESSION_REQUEST", "3 outputs; gate=" + gate.peekSafe());
            c.createCaptureSession(config);
        } catch (Exception e) {
            fail("SESSION_CONFIG_EXCEPTION", e);
            closeCamera();
        }
    }

    private void startPreview(boolean includeYuv) {
        if (device == null || session == null) return;
        try {
            CaptureRequest.Builder b = newBuilder(CameraDevice.TEMPLATE_PREVIEW);
            addRequestKeys(b);
            b.addTarget(rawReader.getSurface());
            if (includeYuv) b.addTarget(yuvReader.getSurface());
            session.setRepeatingRequest(b.build(), new CameraCaptureSession.CaptureCallback() {}, worker);
            info("RAW_PREVIEW_STARTED", "with_yuv=" + includeYuv);
        } catch (Exception e) { fail("RAW_PREVIEW_FAILED", e); }
    }

    private void onRawPreview(ImageReader reader) {
        Image image = null;
        try {
            image = reader.acquireLatestImage();
            if (image == null) return;
            if (!previewSwitched) {
                previewSwitched = true;
                info("RAW_PREVIEW_FRAME", image.getWidth() + "x" + image.getHeight());
                startPreview(false); // Keep companion configured, but stop targeting it.
            }
        } catch (Exception e) { fail("RAW_PREVIEW_IMAGE", e); }
        finally { if (image != null) image.close(); }
    }

    private void capture50() {
        if (device == null || session == null) {
            info("CAPTURE_REFUSED", "Camera/session not configured");
            return;
        }
        try {
            lastStillResult.set(null);
            CaptureRequest.Builder b = newBuilder(CameraDevice.TEMPLATE_STILL_CAPTURE);
            addRequestKeys(b);
            addStillKeys(b);
            b.addTarget(rawReader.getSurface());
            b.addTarget(fullReader.getSurface());
            session.capture(b.build(), new CameraCaptureSession.CaptureCallback() {
                @Override public void onCaptureCompleted(CameraCaptureSession s,
                         CaptureRequest request, TotalCaptureResult result) {
                    lastStillResult.set(result);
                    info("CAPTURE_RESULT", "frame=" + result.getFrameNumber()
                            + " sensorTimestamp=" + result.get(CaptureResult.SENSOR_TIMESTAMP));
                }
                @Override public void onCaptureFailed(CameraCaptureSession s,
                         CaptureRequest request, android.hardware.camera2.CaptureFailure failure) {
                    info("CAPTURE_FAILED", "reason=" + failure.getReason());
                }
            }, worker);
            info("CAPTURE_50_SUBMITTED", "RAW full=8192x6144 camera=" + activeCameraId);
        } catch (Exception e) { fail("CAPTURE_SUBMIT_FAILED", e); }
    }

    private void onFullRaw(ImageReader reader) {
        Image image = null;
        try {
            image = reader.acquireNextImage();
            if (image == null) return;
            final Image held = image;
            image = null;
            ++capturedImages;
            info("FULLRES_RAW_RECEIVED", "count=" + capturedImages +
                    " width=" + held.getWidth() + " height=" + held.getHeight() +
                    " format=" + held.getFormat() + " ts=" + held.getTimestamp());
            try {
                HardwareBuffer hb = held.getHardwareBuffer();
                if (hb != null) {
                    info("FULLRES_HWBUFFER", "w=" + hb.getWidth() + " h=" + hb.getHeight() +
                            " fmt=" + hb.getFormat() + " layers=" + hb.getLayers() +
                            " usage=" + hb.getUsage());
                    hb.close();
                } else { info("FULLRES_HWBUFFER", "null"); }
            } catch (Exception e) { info("FULLRES_HWBUFFER_ERROR", e.toString()); }
            // Capture result may arrive after the ImageReader callback.
            worker.postDelayed(() -> saveOrInspect(held), 400);
        } catch (Exception e) { fail("FULLRES_IMAGE_ERROR", e); }
        finally { if (image != null) image.close(); }
    }

    private void saveOrInspect(Image image) {
        try {
            try {
                Image.Plane[] planes = image.getPlanes();
                if (planes.length > 0) {
                    info("RAW_PLANE", "rowStride=" + planes[0].getRowStride() +
                            " pixelStride=" + planes[0].getPixelStride() +
                            " remaining=" + planes[0].getBuffer().remaining());
                }
            } catch (Exception e) {
                info("RAW_PLANE_UNAVAILABLE", "GPU_DATA_BUFFER path: " + e.getClass().getSimpleName());
            }
            TotalCaptureResult result = lastStillResult.get();
            if (result == null || characteristics == null) {
                info("DNG_NOT_READY", "No matching TotalCaptureResult; keep RAW diagnostic only");
                return;
            }
            ContentValues values = new ContentValues();
            String file = "XENIUS_" + activeCameraId + "_H50_" + System.currentTimeMillis() + ".dng";
            values.put(MediaStore.Images.Media.DISPLAY_NAME, file);
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/x-adobe-dng");
            values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_DCIM + "/XeniusFullRes");
            values.put(MediaStore.Images.Media.IS_PENDING, 1);
            ContentResolver cr = getContentResolver();
            Uri uri = cr.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new IllegalStateException("MediaStore.insert returned null");
            try {
                try (OutputStream out = cr.openOutputStream(uri); DngCreator dng = new DngCreator(characteristics, result)) {
                    if (out == null) throw new IllegalStateException("MediaStore OutputStream null");
                    dng.writeImage(out, image);
                }
                ContentValues finish = new ContentValues();
                finish.put(MediaStore.Images.Media.IS_PENDING, 0);
                cr.update(uri, finish, null, null);
                info("DNG_WRITTEN", "file=" + file + " (CHECK Bayer and 64/1023 tags!)");
            } catch (Exception e) {
                cr.delete(uri, null, null);
                throw e;
            }
        } catch (Exception e) {
            fail("DNG_WRITE_UNSUPPORTED", e);
            info("NEXT_DIAGNOSTIC", "HardwareBuffer NDK lock/copy needed if GPU-only RAW plane blocked");
        } finally { image.close(); }
    }

    private void cleanupReaders() {
        session = null;
        previewSwitched = false;
        lastStillResult.set(null);
        if (rawReader != null) { rawReader.close(); rawReader = null; }
        if (fullReader != null) { fullReader.close(); fullReader = null; }
        if (yuvReader != null) { yuvReader.close(); yuvReader = null; }
    }
    private void closeCamera() {
        info("CLOSE_REQUESTED", "camera=" + activeCameraId + " pending=" + openPending);
        if (session != null) { session.close(); session = null; }
        if (device != null) { device.close(); /* gate restored in onClosed */ }
        else if (!openPending) { cleanupReaders(); gate.restore(); }
        else { info("CLOSE_DEFERRED", "waiting for camera open/onError callback"); }
    }
    @Override protected void onDestroy() {
        worker.post(this::closeCamera);
        super.onDestroy();
    }

    private final class VivoGate {
        private Object instance;
        private Method getInfo, setValue;
        private Integer previous;
        private boolean owned;
        private final String PENDING = "gate_owned";
        private final String BEFORE = "gate_previous";
        private void init() throws Exception {
            if (instance != null) return;
            Class<?> cls = Class.forName("android.hardware.vivocamera.VivoCameraManager");
            instance = cls.getMethod("getInstance").invoke(null);
            getInfo = cls.getMethod("getInfo", int.class);
            setValue = cls.getMethod("setValue", int.class, int.class);
        }
        int peek() throws Exception {
            init();
            Object value = getInfo.invoke(instance, 40);
            return ((Number)value).intValue();
        }
        String peekSafe() {
            try { return Integer.toString(peek()); }
            catch (Exception e) { return "unreadable"; }
        }
        String state() {
            return "key1=" + peekIdSafe(1) + " key33=" + peekIdSafe(33) + " key40=" + peekIdSafe(40);
        }
        String peekIdSafe(int id) {
            try { init(); return Integer.toString(((Number)getInfo.invoke(instance, id)).intValue()); }
            catch (Exception e) { return "?"; }
        }
        void recoverIfLeftActive() {
            if (!getPreferences(Context.MODE_PRIVATE).getBoolean(PENDING, false)) return;
            int prev = getPreferences(Context.MODE_PRIVATE).getInt(BEFORE, -1);
            try {
                if (prev >= 0 && peek() == 1) {
                    setValue.invoke(instance, 40, prev);
                    info("VIVO_GATE_RECOVERED", "restored=" + prev);
                }
                getPreferences(Context.MODE_PRIVATE).edit().putBoolean(PENDING, false).apply();
            } catch (Exception e) { fail("VIVO_GATE_RECOVERY_FAILED", e); }
        }
        boolean acquire() {
            try {
                previous = peek();
                if (previous < 0) throw new IllegalStateException("Cannot read previous key40");
                getPreferences(Context.MODE_PRIVATE).edit()
                        .putInt(BEFORE, previous).putBoolean(PENDING, true).commit();
                setValue.invoke(instance, 40, 1);
                // The vendor provider update is asynchronous on some firmware.
                SystemClock.sleep(200);
                if (peek() != 1) throw new IllegalStateException("key40 did not become 1");
                owned = true;
                info("VIVO_GATE_ACQUIRED", "before=" + previous + " now=" + peek());
                info("VIVO_GATE_STATE", "stage=acquired " + state());
                return true;
            } catch (Exception e) {
                fail("VIVO_GATE_ACQUIRE_FAILED", e);
                restore();
                return false;
            }
        }
        void restore() {
            if (previous == null) return;
            try {
                init();
                setValue.invoke(instance, 40, previous);
                SystemClock.sleep(100);
                info("VIVO_GATE_RESTORED", "expected=" + previous + " actual=" + peekSafe());
                info("VIVO_GATE_STATE", "stage=restored " + state());
                getPreferences(Context.MODE_PRIVATE).edit().putBoolean(PENDING, false).commit();
                owned = false;
                previous = null;
            } catch (Exception e) { fail("VIVO_GATE_RESTORE_FAILED", e); }
        }
    }
}
